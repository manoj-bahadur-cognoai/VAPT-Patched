/**
 * Inbound postMessage hardening for EasyChat chatbot iframes.
 * Mitigates DOM XSS from unvalidated cross-origin postMessage (VAPT).
 *
 * Allowed senders:
 * - Same origin as the chatbot (bot URL domain)
 * - Origins in window.POSTMESSAGE_ALLOWED_ORIGINS (whitelisted embed parents)
 */
(function (global) {
    'use strict';

    function get_postmessage_allowed_origins() {
        var origins = [];
        if (typeof global.POSTMESSAGE_ALLOWED_ORIGINS !== 'undefined' &&
            Object.prototype.toString.call(global.POSTMESSAGE_ALLOWED_ORIGINS) === '[object Array]') {
            for (var i = 0; i < global.POSTMESSAGE_ALLOWED_ORIGINS.length; i++) {
                var origin = global.POSTMESSAGE_ALLOWED_ORIGINS[i];
                if (typeof origin === 'string' && origin && origin !== '*' &&
                    origins.indexOf(origin) === -1) {
                    origins.push(origin);
                }
            }
        }
        // Always allow the chatbot's own origin (same-domain parent / cobrowse host)
        if (origins.indexOf(global.location.origin) === -1) {
            origins.push(global.location.origin);
        }
        return origins;
    }

    function is_allowed_postmessage_origin(origin) {
        if (!origin || typeof origin !== 'string' || origin === '*') {
            return false;
        }
        return get_postmessage_allowed_origins().indexOf(origin) !== -1;
    }

    /**
     * Exact origin match against a server URL (embed parent listening to iframe).
     * Rejects substring matches and "*". Never use indexOf(SERVER_URL).
     */
    function is_allowed_server_postmessage_origin(origin, serverUrl) {
        if (!origin || typeof origin !== 'string' || origin === '*') {
            return false;
        }
        if (!serverUrl || typeof serverUrl !== 'string') {
            return false;
        }
        try {
            var serverOrigin;
            if (typeof URL !== 'undefined') {
                serverOrigin = new URL(serverUrl, global.location.href).origin;
            } else {
                var match = serverUrl.match(/^(https?:\/\/[^\/?#]+)/i);
                serverOrigin = match ? match[1] : '';
            }
            return !!serverOrigin && origin === serverOrigin;
        } catch (err) {
            return false;
        }
    }

    function coerce_postmessage_string(value) {
        if (value === null || typeof value === 'undefined') {
            return '';
        }
        return String(value);
    }

    function sanitize_postmessage_url(url) {
        if (url === null || typeof url === 'undefined' || url === 'None' || url === '') {
            return null;
        }
        url = String(url).trim();
        if (/^(javascript|data|vbscript):/i.test(url)) {
            return null;
        }
        return url;
    }

    /**
     * Normalize payload for safe textContent rendering (no HTML entity encoding —
     * textContent assigns plain text; encoding would show literal &lt; to users).
     */
    function normalize_incoming_postmessage_payload(data) {
        if (!data || typeof data !== 'object') {
            return data;
        }
        var string_fields = [
            'message', 'name', 'agent_name', 'client_name',
            'attachment_file_name', 'time', 'agent_connect_message', 'chat_type'
        ];
        for (var i = 0; i < string_fields.length; i++) {
            var key = string_fields[i];
            if (Object.prototype.hasOwnProperty.call(data, key) && data[key] != null) {
                data[key] = coerce_postmessage_string(data[key]);
            }
        }
        if (Object.prototype.hasOwnProperty.call(data, 'attachment')) {
            if (data.attachment === 'None' || data.attachment === null || data.attachment === '') {
                data.attachment = null;
            } else {
                data.attachment = sanitize_postmessage_url(data.attachment);
            }
        }
        if (Object.prototype.hasOwnProperty.call(data, 'agent_profile_pic_source') &&
            data.agent_profile_pic_source) {
            var safe_pic = sanitize_postmessage_url(data.agent_profile_pic_source);
            data.agent_profile_pic_source = safe_pic || '';
        }
        return data;
    }

    /**
     * Returns parsed payload if origin is trusted; otherwise null.
     * Does not accept wildcard origins.
     */
    function parse_trusted_postmessage(event) {
        if (!event || !is_allowed_postmessage_origin(event.origin)) {
            return null;
        }

        var raw = event.data;
        var data = null;
        try {
            if (typeof raw === 'string') {
                var trimmed = raw.trim();
                if (!trimmed || (trimmed.charAt(0) !== '{' && trimmed.charAt(0) !== '[')) {
                    return null;
                }
                data = JSON.parse(trimmed);
            } else if (typeof raw === 'object' && raw !== null) {
                data = raw;
            } else {
                return null;
            }
        } catch (err) {
            return null;
        }
        return normalize_incoming_postmessage_payload(data);
    }

    global.get_postmessage_allowed_origins = get_postmessage_allowed_origins;
    global.is_allowed_postmessage_origin = is_allowed_postmessage_origin;
    global.is_allowed_server_postmessage_origin = is_allowed_server_postmessage_origin;
    global.coerce_postmessage_string = coerce_postmessage_string;
    global.sanitize_postmessage_url = sanitize_postmessage_url;
    global.normalize_incoming_postmessage_payload = normalize_incoming_postmessage_payload;
    global.parse_trusted_postmessage = parse_trusted_postmessage;
})(typeof window !== 'undefined' ? window : this);
