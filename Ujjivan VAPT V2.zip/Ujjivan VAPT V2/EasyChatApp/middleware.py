from django.conf import settings
from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import HttpResponseRedirect, redirect
from django.contrib import auth
from datetime import datetime, timedelta
from EasyChatApp.models import *
from EasyChatApp.utils import *
from EasyChatApp.constants import *
from DeveloperConsoleApp.utils import get_developer_console_settings

import sys
import json
import logging
import ipaddress
import hashlib
from django.contrib.sessions.models import Session

logger = logging.getLogger(__name__)


class IPAddressCheckMiddleware(object):

    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def ip_address_in_given_range(self, start_ip_address, end_ip_address, check_ip_address):
        try:
            start_address = ipaddress.IPv4Address(start_ip_address)
            end_address = ipaddress.IPv4Address(end_ip_address)
            check_address = ipaddress.IPv4Address(check_ip_address)

            if check_address >= start_address and check_address <= end_address:
                return True
            else:
                return False
        except Exception:
            return False

    def check_path_is_blocked(self, request_path_info, blocked_request_path_list):
        for blocked_request_path in blocked_request_path_list:
            if request_path_info.startswith(blocked_request_path):
                return True
        return False

    def __call__(self, request):

        client_ip_address = request.META.get('HTTP_X_FORWARDED_FOR')
        request_path_info = request.META.get('PATH_INFO')

        logger.error(f"Clinet IP is ----------{client_ip_address} --- path is --  {request_path_info}")
        logger.error(f"Clinet IP is 2---- {request.META.get('HTTP_X_FORWARDED_FOR',request.META.get('REMOTE_ADDR'))} -- ")
        config_obj = get_developer_console_settings()
        whitelisted_ip_address_list = config_obj.get_whitelisted_ip_addresses()
        
        whitelisted_request_path_list = settings.WHITELISTED_URLPATTERNS
        whitelisted_ips_for_blocked_urls = settings.WHITELISTED_IP_FOR_BLOCKED_URLS
        blocked_request_path_list = settings.BLOCKED_URLPATTERNS
        client_real_ip_address = client_ip_address
        if client_real_ip_address:
            client_real_ip_address = client_real_ip_address.split(',')
        else:
            client_real_ip_address = ""

        origin = request.META.get('HTTP_ORIGIN')
        if origin != None and settings.DEBUG == False and settings.CORS_ORIGIN_ALLOW_ALL == False:
            cors_origin_whitelist = settings.CORS_ORIGIN_WHITELIST
            origin = urlparse(origin)
            if origin.scheme + "://" + origin.netloc not in cors_origin_whitelist:
                return HttpResponse(status=401)

            if origin.path != "":
                return HttpResponse(status=401)

        if self.check_path_is_blocked(request_path_info, blocked_request_path_list):
            is_valid_ip = False
            for ip in client_real_ip_address:
                ip = ip.strip()
                if not ip:
                    continue
                if ip in whitelisted_ips_for_blocked_urls:
                    is_valid_ip = True
                    break
            if not is_valid_ip:
                return HttpResponse(status=401)

        if request_path_info not in whitelisted_request_path_list and len(whitelisted_ip_address_list) != 0:
            is_valid_user = False

            for ip_address in whitelisted_ip_address_list:
 
                for ip_item in client_real_ip_address:
                    ip_item = ip_item.strip()
                    if not ip_item:
                        continue
                    if isinstance(ip_address, str) and ip_address == ip_item:
                        is_valid_user = True
                    if isinstance(ip_address, tuple) and len(ip_address) == 2:
                        if self.ip_address_in_given_range(ip_address[0], ip_address[1], ip_item):
                            is_valid_user = True
                            break
            if not is_valid_user:
                return HttpResponse(status=401)

        # Code to be executed for each request before
        # the view (and later middleware) are called.
        response = self.get_response(request)

        return response


class AutoLogout(object):

    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def get_client_ip(self, request):
        try:
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR', '')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR', '')
            return ip
        except Exception as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(
                f'Error AutoLogout : get_client_ip {err} at {str(exc_tb.tb_lineno)}')
            return ''

    def is_valid_fingerprint(self, user_session, hashed_fingerprint):
        try:
            return user_session.client_fingerprint == hashed_fingerprint
        except Exception as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(
                f'Error AutoLogout : is_valid_fingerprint {err} at {str(exc_tb.tb_lineno)}')
            return False

    def __call__(self, request):

        # Can't log out if not logged in
        if not request.user.is_authenticated:
            response = self.get_response(request)
            return response

        try:
            # searching user session by session key
            user_session = UserSession.objects.filter(
                session_key=request.session.session_key).first()
            user = request.user

            hashed_fingerprint = ""
            if settings.IS_FINGERPRINT_AUTHENTICATION_ENABLED:
                client_fingerprint = {}
                client_fingerprint['client_ip'] = self.get_client_ip(request)
                client_fingerprint['http_user_agent'] = request.META.get(
                    'HTTP_USER_AGENT', '')
                client_fingerprint['http_accept_language'] = request.META.get(
                    'HTTP_ACCEPT_LANGUAGE', '')

                fingerprint_string = json.dumps(
                    client_fingerprint, sort_keys=True)
                hashed_fingerprint = hashlib.sha256(
                    fingerprint_string.encode()).hexdigest()

                if user_session and not self.is_valid_fingerprint(user_session, hashed_fingerprint):
                    response = HttpResponseRedirect('/chat/login')
                    response.delete_cookie('sessionid')
                    response.set_cookie('is_online', 0, settings.COOKIE_SECURE, settings.COOKIE_SAMESITE, settings.COOKIE_PATH)
                    return response

            if not user_session:
                # if user newly logged in then create UserSession object
                # for that user
                UserSession.objects.create(
                    session_key=request.session.session_key, user=user, client_fingerprint=hashed_fingerprint)
            else:
                # is user session object found for that particular request session then
                # update last request datetime
                # user_session = user_session
                user_session.last_update_datetime = timezone.now()
                user_session.save(update_fields=['last_update_datetime'])

            user.is_online = True
            user.save(update_fields=['is_online'])
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Error AutoLogout %s at %s",
                         str(e), str(exc_tb.tb_lineno))

        response = self.get_response(request)
        return response

class RestrictSessionMiddleware:
    #logger.error("inside Restrict session middleware", extra={'AppName': 'EasyChat', 'user_id': 'None', 'source': 'None', 'channel': 'None', 'bot_id': 'None'})
    def __init__(self, get_response):
        #logger.error("inside Restrict session middleware", extra={'AppName': 'EasyChat', 'user_id': 'None', 'source': 'None', 'channel': 'None', 'bot_id': 'None'})
        self.get_response = get_response

    def __call__(self, request):
        response = self.process_request(request)
        if response:
            return response
        return self.get_response(request)

    def process_request(self, request):
        logger.error("inside Process Request method of Restrict session middleware")
        try:
            if not request.session.session_key:
                return
            logger.error("after return of the Method")
            user_agent = request.META.get('HTTP_USER_AGENT', '')
            ip_address = self.get_client_ip(request)
            session_browser = request.session.get('browser')
            session_ip = request.session.get('ip_address')
            logger.error(f"Session Hijacking : ip address - {ip_address} & user agent - {user_agent}")
            print("ip address", ip_address, "user agent", user_agent)
            if session_browser is None or session_ip is None:
                request.session['browser'] = user_agent
                request.session['ip_address'] = ip_address
                logger.error(f"session middleware if of ip assign")
            elif session_browser != user_agent or session_ip != ip_address:
                request.session.flush()
                logger.error(f"session middleware elif of ip assignin")
                return redirect(f'{settings.BASE_PATH}/chat/login')
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("session middleware Error RestrictSessionMiddleware in process_request %s at %s",str(e), str(exc_tb.tb_lineno))

    @staticmethod
    def get_client_ip(request):
        try:
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR')
            logger.error(f"Session Hijacking : ip address - {ip}")
            logger.error(f"session middleware request meta data---- {request.META}")
            return ip
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("session middleware Error RestrictSessionMiddleware in get_client_ip %s at %s",str(e), str(exc_tb.tb_lineno))



class SecurityHeaderMiddleware:
    try:
        def __init__(self, get_response):
            self.get_response = get_response
            self._frame_ancestors_csp = self._build_frame_ancestors_csp()

        @staticmethod
        def _build_frame_ancestors_csp():
            """
            Clickjacking control for HTML pages (incl. /chat/index/).
            CSP frame-ancestors allow-lists legitimate embed parents; attackers are blocked.
            Emitted as its own CSP header so it intersects with any nginx CSP (both enforced).
            """
            ancestors = ["'self'"]
            for origin in getattr(settings, 'ALLOWED_EMBED_ORIGINS', []) or []:
                if not origin or origin == '*':
                    continue
                normalized = str(origin).strip().rstrip('/')
                if normalized and normalized not in ancestors:
                    ancestors.append(normalized)
            return 'frame-ancestors ' + ' '.join(ancestors)

        def __call__(self, request):
            response = self.get_response(request)
            response["Cross-Origin-Embedder-Policy"] = "require-corp"
            response["Cross-Origin-Resource-Policy"] = "cross-origin"
            response["X-Permitted-Cross-Domain-Policies"] = "none"
            response["Permissions-Policy"]=("geolocation=()," "camera=()," "accelerometer=()," "gyroscope=()," "magnetomoter=()," "microphone=()," "payment=(self)," "usb=()," "fullscreen=(self)")
            response["Cross-Origin-Opener-Policy"] = "same-origin"
            response["Referrer-Policy"] = "strict-origin-when-cross-origin"

            # VAPT clickjacking for embeddable pages (e.g. /chat/index/ is XFO-exempt):
            # allow only 'self' + ALLOWED_EMBED_ORIGINS; block attacker iframes.
            # Skip in DEBUG so local embeds are not blocked (matches X_FRAME_OPTIONS=ALLOWALL).
            if not getattr(settings, 'DEBUG', False):
                existing_csp = response.get('Content-Security-Policy', '')
                if existing_csp and 'frame-ancestors' not in existing_csp:
                    response['Content-Security-Policy'] = (
                        existing_csp.rstrip('; ') + '; ' + self._frame_ancestors_csp
                    )
                elif not existing_csp:
                    response['Content-Security-Policy'] = self._frame_ancestors_csp

            return response
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logger.error("middleware Error : SecurityHeaderMiddleware: in  %s at %s",str(e), str(exc_tb.tb_lineno))



