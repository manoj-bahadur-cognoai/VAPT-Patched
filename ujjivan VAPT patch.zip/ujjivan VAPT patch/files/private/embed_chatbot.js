    var count_trigger = false;
    var element_id = ""
    var timer;
    var flag_timer = true
    var temp_element_id = ""
    var stop_form_assist =false
    var form_assist_intent_name = ""
    var trigger_timer;
    var flag_trigger_timer = false
    var page_category = ""

    /** Exact origin of SERVER_URL for postMessage trust checks (never substring / "*"). */
    function get_easychat_server_origin() {
        try {
            if (typeof SERVER_URL !== 'string' || !SERVER_URL || SERVER_URL === '*') {
                return null;
            }
            var anchor = document.createElement('a');
            anchor.href = SERVER_URL;
            if (!anchor.protocol || !anchor.host) {
                return null;
            }
            return anchor.protocol + '//' + anchor.host;
        } catch (err) {
            return null;
        }
    }

    function is_trusted_chatbot_postmessage_origin(origin) {
        if (!origin || typeof origin !== 'string' || origin === '*') {
            return false;
        }
        var server_origin = get_easychat_server_origin();
        return !!server_origin && origin === server_origin;
    }

    function easychat_add_css(filename){
         var head = document.getElementsByTagName('head')[0];
         var style = document.createElement('link');
         style.href = filename;
         style.type = 'text/css';
         style.rel = 'stylesheet';
         head.append(style);
    }

    // Include script file
    function easychat_add_script(filename){
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.src = filename;
        script.type = 'text/javascript';
        head.append(script);
    }

    easychat_add_css(SERVER_URL+"/static/EasyChatApp/css/embed.css");
    addScript(SERVER_URL + "/static/EasyChatApp/js/crypto-js.min.js")

    var slideIndex=1;

    function easychat_get_url_vars() {
        var vars = {};
        var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
            vars[key] = value;
        });
        return vars;
    }

    function tooIdle() {
        window.onclick = resetTimer;      
        window.onkeypress = resetTimer;   
        window.addEventListener('scroll', resetTimer, true); 

    }

    function plusSlides(n) {
      showSlides(slideIndex += n);
    }

    function currentSlide(n) {
      showSlides(slideIndex = n);
    }

    function remove_image_slider_if_exist(){
        slider_main_container = document.getElementById("modal-image-slider-container");
        if(slider_main_container!=undefined && slider_main_container!=null){
           slider_main_container.remove();
        } 
    }

    function showSlides(n) {
      var i;
      var slides = document.getElementsByClassName("easychat-slideshow-slides");
      var dots = document.getElementsByClassName("easychat-slideshow-dot");

      if (n > slides.length) {slideIndex = 1}    

      if (n < 1) {slideIndex = slides.length}

      for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
      }

      for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
      }

      slides[slideIndex-1].style.display = "block";  
      dots[slideIndex-1].className += " active";
    }
var session_id = ""    
url_params = easychat_get_url_vars();
session_id = url_params["session_id"];


    function append_bot_slider_images(image_url_list){

      remove_image_slider_if_exist();

      image_slidershow_html = '<div style="width:100%; margin-top:0.2em; display:inline-block;" id="easychat-slideshow-container-main-div">\
          <div class="easychat-slideshow-container">';

      total_images = image_url_list.length;

      for(var i=0;i<image_url_list.length;i++){
        current_image_no = i+1;
        image_slidershow_html += '<div class="easychat-slideshow-slides fade">\
                <div class="easychat-slideshow-numbertext">'+current_image_no+' / '+total_images+'</div>\
                <img src="'+image_url_list[i]+'" class="easychat-slideshow-images">\
              </div>';      
      }

        image_slidershow_html += '<a class="easychat-slideshow-prev" onclick="plusSlides(-1)">&#10094;</a>\
          <a class="easychat-slideshow-next" onclick="plusSlides(1)">&#10095;</a>\
        </div><br><div style="text-align:center">';

        for(var i=0;i<image_url_list.length;i++){
            current_image_no=i+1;
            image_slidershow_html += '<span class="easychat-slideshow-dot" onclick="currentSlide('+current_image_no+')"></span>';
        }
            
        image_slidershow_html += '</div></div>';

        main_slider_modal = '<div id="modal-image-slider-container" class="modal" style="hei">\
                  <div class="modal-content">\
                    <div class="row">'+image_slidershow_html+'</div></div></div>';

      
      $('body').append(main_slider_modal);

      $("#modal-image-slider-container").modal({
          full_width: true,
          height:600
      });

      $("#modal-image-slider-container").modal("open");

      slideIndex = 1;

      showSlides(slideIndex);
    }



    function openChatBot(){
        openFormAssist();
        flag_timer = true;
        clearTimeout(timer);
    }

    function resetTimer() {
        clearTimeout(timer);
        if(flag_timer==false && stop_form_assist==false){
          timer = setTimeout(openChatBot,5000);
        }
    }

    function callTriggerIntent(){
      triggerIntent();
      count_trigger = true;
      flag_trigger_timer = true;
      clearTimeout(trigger_timer);
    }

    function resetTimerTrigger() {
        // console.log("Inside Reset timer...")
        if(flag_trigger_timer==false && count_trigger == false){
          trigger_timer = setTimeout(callTriggerIntent,10000);
        }
    }

    function get_md5_string(element){
        console.log(element);
        var string = "";
        /*if(element.getAttribute("easy-assist-tag-id")!=null){
            string = element.getAttribute("easy-assist-tag-id");
        }else*/
        if(element.getAttribute("id")!=null){
            string = element.getAttribute("id");
        }else if(element.getAttribute("data-id")!=null){
            string = element.getAttribute("data-id");
        }else{
            string = element.outerHTML;
            string = string.replace(/style="[^"]*"/, ""); // remove style tag from html string
            string = string.replace(/ /g, ""); // remove whitespace from html string
            // console.log(string);
        }
	return CryptoJS.MD5(string).toString();
    }

    window.onload = function() {

        // is_form_assist = document.getElementById("allincall-bot-"+BOT_ID).getAttribute("is_form_assist");

        if(true){
            window.onload = resetTimerTrigger;

            resetTimerTrigger();

        }

        if(is_form_assist=="true"){

          //console.log("Inside If");
            
            tooIdle();

            $(document).ready(function(){

              $(document).delegate("button, input, textarea, select", "focus",function(){
                //console.log("inside focus");
                element = document.activeElement;
                // element_id = CryptoJS.MD5(element.outerHTML.toString()).toString();
                element_id = get_md5_string(element);

                if(temp_element_id != element_id){
                    console.log("Currently focused at "+element_id);
                    $('#allincall-chat-box', window.document).hide("slow");
                    $('#allincall-popup', window.document).show("slow");
                    flag_timer = false;
                    flag_trigger_timer = true;
                    clearTimeout(trigger_timer);
                    resetTimer();
                    temp_element_id = element_id;
                }
                
              });

              $("input, textarea, select").focusout(function(){
                  flag_timer = true;
                  clearTimeout(timer);
                  flag_trigger_timer = false;
                  resetTimerTrigger();

              });
            });
        }
        
        if(session_id==null)
          $('body').append('<iframe id="allincall-chat-box" frameborder="0" style="display:none;z-index:2147483647;" allow="microphone;"></iframe>');

          $.ajax({
              url: SERVER_URL+"/chat/get-bot-image/",
              type: "POST",
              data: {
                bot_id: BOT_ID,
              },
              success: function(response) {

              url_parameters = easychat_get_url_vars();
              bot_id = BOT_ID;

              if(session_id==null){
                if(response["status"]==200)
                {
                    bot_image_url = response['bot_image_url'];
                    if(bot_image_url==''||bot_image_url==null||bot_image_url=='{"items":[]}'){
                        $('body').append('<img id="allincall-popup" src="'+SERVER_URL+'/static/EasyChatApp/img/popup.png" style="position:fixed;cursor:pointer;right:20px;bottom:0;width:10em;z-index:2147483647;">');
                    }else{
                        $('body').append('<img id="allincall-popup" src="'+SERVER_URL+bot_image_url+'" style="position:fixed;cursor:pointer;right:20px;bottom:0;width:10em;z-index:2147483647;">');
                    }
                }else{
                     $('body').append('<img id="allincall-popup" src="'+SERVER_URL+'/static/EasyChatApp/img/popup.png" style="position:fixed;cursor:pointer;right:20px;bottom:0;width:10em;z-index:2147483647;">');
                }
              }

            var auto_pop_timer_handle=null;

              $('#allincall-popup').click(function(e) {

                  if(auto_pop_timer_handle!=null){
                      clearTimeout(auto_pop_timer_handle);
                  }

                  var current_src = $("#allincall-chat-box").attr("src");
                  if((typeof current_src === 'undefined') || (current_src == null)){
                  }
                  else{
                    $("#allincall-chat-box").slideDown("slow");
                  }
                  $('#allincall-popup').hide("slow");
                  $("#allincall-chat-box").slideDown("slow");
                  $("#allincall-chat-box").attr("src",SERVER_URL+"/chat/index/?id="+BOT_ID+'&name='+BOT_NAME+'&is_form_assist='+is_form_assist+'&id='+BOT_ID+'&form_assist_intent_name='+form_assist_intent_name+'&page_category='+page_category.toString());
              });

              if(response["status"]==200 && response["is_auto_pop_allowed"]==true){
                 auto_pop_timer_handle = setTimeout(function(e){
                      $("#allincall-popup").click();
                 }, response["auto_pop_timer"]*1000);              
              }

            },
            error: function(xhr, textstatus, errorthrown) {
               console.log("Please report this issue: ", xhr, textstatus, errorthrown);
            }
        });
        window.addEventListener('message', function(event) { 
                // Only accept messages from the chatbot host origin (exact match)
                if (is_trusted_chatbot_postmessage_origin(event.origin)) { 
                    // The data has been sent from your site 
                    // The data sent with postMessage is stored in event.data 

                    if(event.data.event_id === 'show-image-slider-into-parent'){
                        append_bot_slider_images(event.data.data.image_url_list);
                        // append_easychat_main_slider_image_modal(event.data.data.image_url_list);
                    }
                    if(event.data=="minimize-chatbot"){
                        $('#allincall-chat-box', window.document).hide("slow");
                        $('#allincall-popup', window.document).show("slow");
                        minimized_chatbot = true;
                        page_category = "";
                        form_assist_intent_name = "";
                    }
                    if(event.data=="close-bot"){
                        $('#allincall-chat-box', window.document).hide("slow");
                        $('#allincall-popup', window.document).show("slow");
                        page_category = "";
                        form_assist_intent_name = "";
                    }
                    if(event.data=="share-screen"){
                      // console.log("ABCD");
                      share_screen();
                    }
                    if(event.data=='stop-form-assist'){
                      clearTimeout(timer);
                      stop_form_assist=true
                      form_assist_intent_name = "";
                    }
                } else {
                    // The data hasn't been sent from your site! 
                    // Be careful! Do not use it. 
                    return; 
                }

        });
    }

    // url_params = easychat_get_url_vars();
    // is_store_history = url_params["store_history"];
    // if (is_store_history == "true"){
    //   setTimeout(function(){ $('#allincall-popup').click(); },1000);
    // }


function openFormAssist() {
    var CSRF_TOKEN = $('input[name="csrfmiddlewaretoken"]').val();
    $.ajax({
        url: SERVER_URL+"/chat/form-assist-response/",
        type: "POST",
        headers: {
            'X-CSRFToken': CSRF_TOKEN
        },
        data: {
            tag_id : element_id,
            bot_id : bot_id
        },
        success: function(response) {
            if(response['status']==200){
                form_assist_intent_name = response["form_assist_intent_name"];
		if(form_assist_intent_name!="")
                	$('#allincall-popup').click();
                // console.log(form_assist_intent_name);
            }
            else{
            }
        },
        error: function(xhr, textstatus, errorthrown) {
        } 

    });
}

function triggerIntent() {
    var CSRF_TOKEN = $('input[name="csrfmiddlewaretoken"]').val();
    // console.log("inside triggerIntent");
    url = window.location.href;
    $.ajax({
        url: SERVER_URL+"/chat/trigger-intent/",
        type: "POST",
        headers: {
            'X-CSRFToken': CSRF_TOKEN
        },
        data: {
            url: url
        },
        success: function(response){
            if(response['status']==200){
                page_category = response["category"];
                //console.log(page_category);
		if(page_category!="" && page_category!=null && page_category!=undefined){
                    $('#allincall-popup').click();
                }
            }else{

            }
        },
        error: function(xhr, textstatus, errorthrown) {

        }
    });
}
