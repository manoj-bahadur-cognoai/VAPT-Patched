import base64
import json
import sys
import urllib.parse
from datetime import datetime

from cryptography.hazmat.primitives import serialization
from django.core.cache import cache
from django.http import HttpResponse, HttpResponseNotFound
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from CustomApp.captcha_service import (
    CAPTCHA_MAX_LIMIT_MESSAGE,
    clear_captcha_attempts,
    create_captcha_challenge,
    extract_captcha_id_from_url,
    get_captcha_image_bytes,
    get_captcha_owner,
    is_captcha_validation_locked,
    record_invalid_captcha_attempt,
    verify_captcha,
)
from CustomApp.models import *
from DeveloperConsoleApp.utils import initialize_logger
from EasyChatApp.constants import *
from EasyChatApp.models import *
from EasyChatApp.utils import *
from EasyChatApp.utils_execute_query import save_data
from EasyChatApp.views_analytics import CsrfExemptSessionAuthentication
from EasySearchApp.utils_custom_encryption import aes256decrypt
from LiveChatApp.utils import *

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_BOT_ID = 1
COMMON_UTILS_CACHE_TTL = 3600
COMMON_UTILS_CACHE_PREFIX = "CommonUtilsFileCode-"
WHATSAPP_TO_NUMBER = "916364934387"
PRODUCT_CODE_SAVINGS = "SB"
PRODUCT_CODE_FD = "FD"
SCHEME_TYPE_SBA = "SBA"
SCHEME_TYPE_TDA = "TDA"

# Single source of truth for product reply-button labels (values are also WhatsApp bypass text).
PRODUCT_REPLY_BUTTONS = {
    PRODUCT_CODE_SAVINGS: {"dsa": "Open Savings Account"},
    PRODUCT_CODE_FD: {"dfd": "Create FD"},
}
VKYC_APPROVED_STATUS = "VIDEO_KYC_APPROVED"
VKYC_RETRY_STATUSES = frozenset({
    "VIDEO_KYC_RE_OPENED",
    "VIDEO_KYC_UNABLE",
})

logger = initialize_logger("custom_dsa_webhook", "log/custom_dsa_webhook.log", True)


def _log_extra(user_id="", bot_id=""):
    return {
        "AppName": "EasyChat",
        "user_id": str(user_id) if user_id else "",
        "source": "None",
        "channel": "None",
        "bot_id": str(bot_id) if bot_id else "",
    }


def _load_common_utils(bot_id=DEFAULT_BOT_ID):
    """Load (and cache) bot CommonUtilsFile code into a namespace dict."""
    namespace = {}
    cache_key = f"{COMMON_UTILS_CACHE_PREFIX}{bot_id}"
    try:
        common_utils_code = cache.get(cache_key)
        if not common_utils_code:
            bot_obj = Bot.objects.get(pk=bot_id)
            common_utils_obj = CommonUtilsFile.objects.get(bot=bot_obj)
            common_utils_code = common_utils_obj.code
            cache.set(cache_key, common_utils_code, COMMON_UTILS_CACHE_TTL)
        exec(str(common_utils_code), namespace)
    except Exception as exc:
        logger.error(
            "Failed to load CommonUtils for bot %s: %s",
            bot_id,
            exc,
            extra=_log_extra(bot_id=bot_id),
        )
    return namespace


result_dict = _load_common_utils(DEFAULT_BOT_ID)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
def _get_api_key(request):
    return request.headers.get("X-API-KEY") or request.GET.get("api_key")


def _unauthorized(message="Missing API key", status=401):
    return Response(data={"error": message}, status=status)


def _authenticated_captcha_subject(request):
    """
    Canonical captcha owner / rate-limit identity.

    Always auth:{username} so mint and validate compare the same form.
    Never derive this from body user_id (victim lockout / 403 mismatch).
    """
    auth_user = getattr(request, "user", None)
    if not auth_user or not getattr(auth_user, "is_authenticated", False):
        return None
    return f"auth:{auth_user.get_username()}"


def _verified_captcha_profile_user_id(request, body_user_id=""):
    """
    Profile user_id only when bound to the authenticated caller.

    Accept when body user_id matches a session chat id, or equals the auth
    username. Raw unbound body user_id is rejected (cross-profile write).
    """
    auth_user = getattr(request, "user", None)
    if not auth_user or not getattr(auth_user, "is_authenticated", False):
        return None

    body_user_id = str(body_user_id or "").strip()
    if not body_user_id:
        return None

    session = getattr(request, "session", None)
    if session is not None:
        for key in ("user_id", "easychat_user_id", "profile_user_id"):
            session_uid = session.get(key)
            if session_uid is not None and str(session_uid) == body_user_id:
                return body_user_id

    if body_user_id == str(auth_user.get_username()):
        return body_user_id

    return None


def _validate_api_key(
    request,
    log_prefix="API",
    invalid_message="Invalid or inactive API key",
):
    """Return None if valid; otherwise a Response to return immediately."""
    api_key = _get_api_key(request)
    if not api_key:
        logger.error("%s key not passed", log_prefix, extra=_log_extra())
        return _unauthorized("Missing API key", status=401)
    if api_key != result_dict.get("custom_api_auth_key"):
        logger.error("%s key is invalid", log_prefix, extra=_log_extra())
        return _unauthorized(invalid_message, status=403)
    return None


def _get_bot(bot_id=DEFAULT_BOT_ID):
    return Bot.objects.get(pk=int(bot_id))


def _load_whatsapp_webhook_code(bot_id=DEFAULT_BOT_ID):
    code = get_value_from_cache(CACHE_KEY_EASYCHAT_WHATSAPP_WEBHOOK, str(bot_id))
    if not code:
        webhook_qs = WhatsAppWebhook.objects.filter(bot=_get_bot(bot_id))
        if not webhook_qs.exists():
            raise ValueError(f"WhatsAppWebhook not found for bot {bot_id}")
        code = str(webhook_qs[0].function)
        set_value_to_cache(CACHE_KEY_EASYCHAT_WHATSAPP_WEBHOOK, str(bot_id), code)
    return code


def _exec_whatsapp_webhook_namespace(bot_id=DEFAULT_BOT_ID):
    namespace = {}
    exec(_load_whatsapp_webhook_code(bot_id), namespace)
    return namespace


def _build_whatsapp_bypass_packet(phone_number, text, bot_id=DEFAULT_BOT_ID):
    return {
        "incoming_message": [
            {
                "context": {"message_id": "", "ncmessage_id": ""},
                "from": phone_number,
                "from_name": "",
                "message_id": "",
                "message_type": "TEXT",
                "received_at": "",
                "text_type": {"text": text},
                "to": WHATSAPP_TO_NUMBER,
            }
        ],
        "bot_id": str(bot_id),
    }


def _invoke_whatsapp_bypass(phone_number, text, log_prefix="WhatsApp bypass", bot_id=DEFAULT_BOT_ID):
    """Simulate user input by invoking the WhatsApp webhook."""
    try:
        request_packet = _build_whatsapp_bypass_packet(phone_number, text, bot_id)
        namespace = _exec_whatsapp_webhook_namespace(bot_id)
        api_response = namespace["whatsapp_webhook"](request_packet)
        logger.error(
            "%s -- whatsapp_webhook api_response: %s",
            log_prefix,
            api_response,
            extra=_log_extra(bot_id=bot_id),
        )
        return api_response
    except Exception as exc:
        logger.error(
            "%s -- whatsapp_webhook Error: %s",
            log_prefix,
            exc,
            extra=_log_extra(bot_id=bot_id),
        )
        return None


def _product_code_from_ref(ref_id):
    if ref_id and len(ref_id) >= 5:
        return ref_id[3:5]
    return None


def _phone_from_digital(digital_obj):
    return "91" + str(digital_obj.mobile_number)


def _get_product_reply_buttons(product_code):
    buttons = PRODUCT_REPLY_BUTTONS.get(product_code)
    if not buttons:
        raise ValueError(f"Unsupported product code: {product_code}")
    return buttons


def _get_product_bypass_text(product_code):
    """Bypass text is the reply-button label for that product."""
    return next(iter(_get_product_reply_buttons(product_code).values()))


def _resolve_digital_by_ekyc(ekyc_obj, product_code):
    if product_code == PRODUCT_CODE_SAVINGS:
        return DSA.objects.get(ekyc_details=ekyc_obj)
    if product_code == PRODUCT_CODE_FD:
        return DFD.objects.get(ekyc_details=ekyc_obj)
    raise ValueError(f"Unsupported product code: {product_code}")


def _resolve_digital_by_vkyc(vkyc_obj, product_code):
    if product_code == PRODUCT_CODE_SAVINGS:
        return DSA.objects.get(vkyc_details=vkyc_obj)
    if product_code == PRODUCT_CODE_FD:
        return DFD.objects.get(vkyc_details=vkyc_obj)
    raise ValueError(f"Unsupported product code: {product_code}")


def _build_vkyc_retry_message(url, product_code):
    product_action = _get_product_bypass_text(product_code)
    return (
        "Looks like your last Video KYC was unsuccessful. "
        "Please try again using the new link given here.\n\n"
        "Final step - Complete Video KYC \n\n"
        "V-KYC Checklist: \n"
        "*️⃣Please note that Video KYC can be done only from the city of your communication address.\n"
        "*️⃣Keep original PAN, pen & paper ready \n"
        "*️⃣Stable Internet & a well-lit space \n"
        "*️⃣V-KYC link validity: one time use only \n"
        f"{url}\n\n"
        "*️⃣Kindly wait for 24 Hrs, post completion of Video KYC for status update \n\n"
        f"Facing issues? Type '{product_action}'"
    )


def _send_whatsapp_text(phone_number, message, preview_url=True):
    webhook_ns = _exec_whatsapp_webhook_namespace()
    return webhook_ns["send_whatsapp_text_message"](
        None, "null", message, phone_number, preview_url=preview_url
    )


def _regenerate_vkyc_link(digital_obj):
    """Regenerate VKYC URL for an existing application tracking ID."""
    vkyc_obj = digital_obj.vkyc_details
    if not vkyc_obj or not vkyc_obj.vkyc_ref_no:
        raise ValueError("VKYC tracking ID not found on application")

    digital_obj.is_vkyc = True
    digital_obj.save(update_fields=["is_vkyc"])

    ckyc_body_details = digital_obj.ckyc_details.ckyc_json_dump["ckyc_body_details"]
    karza_pan_data = digital_obj.pan_details.pan_details["karza_pan_details"]
    tracking_id = vkyc_obj.vkyc_ref_no

    resp_txt = result_dict["generate_vkyc_link"](
        digital_obj.mobile_number,
        digital_obj,
        karza_pan_data,
        ckyc_body_details,
        tracking_id,
    )
    logger.error(
        "VKYC regenerate generate_vkyc_link response - %s",
        resp_txt,
        extra=_log_extra(),
    )
    if str(resp_txt.get("status_code")) != "200":
        raise ValueError(f"generate_vkyc_link failed: {resp_txt}")

    payload = resp_txt.get("resp_text") or {}
    vkyc_url = payload.get("redirectURL")
    if not vkyc_url:
        raise ValueError("generate_vkyc_link returned no redirectURL")

    dump = vkyc_obj.vkyc_json_dump or {}
    dump.update({"vkyc_url": str(vkyc_url)})
    vkyc_obj.vkyc_json_dump = dump
    vkyc_obj.vkyc_status = "PENDING"
    vkyc_obj.save()

    if digital_obj.user_flow_journey:
        digital_obj.user_flow_journey.vkyc_start_date = datetime.now()
        digital_obj.user_flow_journey.save()
    digital_obj.save()
    return vkyc_url


def _resolve_digital_by_lead(lead_id, scheme_type):
    if scheme_type == SCHEME_TYPE_SBA:
        return DSA.objects.get(lead_id=lead_id)
    if scheme_type == SCHEME_TYPE_TDA:
        return DFD.objects.get(lead_id=lead_id)
    raise ValueError(f"Unsupported scheme type: {scheme_type}")


def _decrypt_rsa_aes_payload(kek_b64, encrypted_value):
    """Decrypt KEK (RSA-OAEP) then AES-256 payload used by account/payment APIs."""
    clear = result_dict["rsaDecryptionOaepSha256FromBase64New"](
        result_dict["DSA_CLIENT_PRIVATE_KEY_PEM"],
        kek_b64,
        result_dict["chatbot_priv_pass"],
    )
    key_iv = base64.b64decode(clear).split(b":")
    key_str = key_iv[0].decode("utf-8")
    iv_bytes = key_iv[1]
    decrypted_data = aes256decrypt(encrypted_value, key_str, iv_bytes)
    plaintext = json.loads(decrypted_data.replace(iv_bytes.decode("utf-8"), ""))
    return plaintext, decrypted_data


def _decrypt_ekyc_payload(request_body):
    cert = serialization.load_pem_private_key(
        result_dict["DSA_CLIENT_PRIVATE_KEY_PEM"],
        password=result_dict["chatbot_priv_pass"],
    )
    key_iv_b64 = result_dict["decrypt_kek_ekyc"](request_body["kek"], cert)
    key = base64.b64decode(key_iv_b64[0])
    iv = base64.b64decode(key_iv_b64[1])
    ciphertext_with_tag = base64.b64decode(request_body["cipherText"])
    plaintext_bytes = result_dict["aes256_gcm_decrypt_ekyc"](ciphertext_with_tag, key, iv)
    return json.loads(plaintext_bytes.decode("utf-8", errors="replace"))


def _parse_json_string_payload(request):
    raw = urllib.parse.unquote(request.data["json_string"])
    return json.loads(raw)


def _exception_lineno():
    exc_tb = sys.exc_info()[2]
    return exc_tb.tb_lineno if exc_tb else "?"


def _build_sba_success_message(digital_obj, plaintext, scheme_code):
    product = result_dict["sa_product_list"]["sa_product"][str(scheme_code)]
    details = plaintext["details"]
    account_dtls = details["accountDtls"]
    return (
        f"Dear {digital_obj.user_details.full_name}, \n \n"
        "Congratulations! \n \n"
        f"Your {product['product_name']} is successfully opened. \n \n"
        "Here are your account details: \n \n"
        f"Type of Account: {product['product_name']} \n"
        f"Account Number: {details['accountNumber']} \n"
        f"Customer ID: {account_dtls['cifId']} \n"
        f"IFSC Code: {account_dtls['ifscCode']} \n"
        f"Branch: {account_dtls['branchName']} Branch \n"
        "Product Features: https://www.ujjivansfb.bank.in/personal/savings-account \n \n"
        "Next Steps: \n"
        "    1. Save 9002082121 as Ujjivan SFB WhatsApp Banking number in your contacts. \n"
        "    2. WhatsApp Banking offers 70+ services \n"
        "    3. Open an FD, download statement, Account balance, Apply for Loans, insurance & investments \n"
        "    4. Download Ujjivan EZY mobile banking app \n"
        "    5. Activate your Debit Card (if opted-in) once you receive the same. \n"
        "    6. Your security is our priority. Never share your OTP, PIN, or password with anyone. \n"
        "    7. Need help? Say “Hi” on Ujjivan SFB WhatsApp or call us on 1800 208 2121. \n \n"
        "Thank you for choosing Ujjivan SFB. We look forward to serving you."
    )


def _build_tda_success_message(digital_obj, plaintext):
    details = plaintext["details"]
    account_dtls = details["accountDtls"]
    return (
        f"Dear {digital_obj.user_details.full_name}, \n \n"
        "Congratulations! \n \n"
        f"Your {account_dtls['schemeType']} is successfully opened. \n \n"
        "Here are your account details: \n \n"
        f"Account Number: {details['accountNumber']} \n"
        f"Customer ID: {account_dtls['cifId']} \n"
        f"Branch: {account_dtls['branchDescription']} Branch \n"
        "Product Features: https://www.ujjivansfb.bank.in/personal/deposits \n \n"
        "Next Steps: \n"
        "    1. Save 9002082121 as Ujjivan SFB WhatsApp Banking number in your contacts. \n"
        "    2. WhatsApp Banking offers 70+ services \n"
        "    3. Open an FD, download statement, Account balance, Apply for Loans, insurance & investments \n"
        "    4. Download Ujjivan EZY mobile banking app \n"
        "    5. Your security is our priority. Never share your OTP, PIN, or password with anyone. \n"
        "    6. Need help? Say “Hi” on Ujjivan SFB WhatsApp or call us on 1800 208 2121. \n \n"
        "Thank you for choosing Ujjivan SFB. We look forward to serving you."
    )


def _update_or_create_account_details(digital_obj, plaintext, decrypted_data):
    account_number = plaintext["details"]["accountNumber"]
    if digital_obj.account_creation_details:
        acc = digital_obj.account_creation_details
        acc.account_number = account_number
        acc.account_open_date = datetime.now()
        acc.account_json_dump = decrypted_data
        acc.account_status = "OPEN"
        acc.save()
    else:
        digital_obj.account_creation_details = AccountCreationDetails.objects.create(
            account_number=account_number,
            account_open_date=datetime.now(),
            account_status="OPEN",
            account_json_dump=plaintext,
        )
    digital_obj.application_status = "COMPLETED"
    digital_obj.save()


AUTH_CLASSES = (CsrfExemptSessionAuthentication, BasicAuthentication)
SUCCESS_PAYLOAD = {"status": "success", "message": "Payload accepted"}


# ---------------------------------------------------------------------------
# EKYC / VKYC webhooks
# ---------------------------------------------------------------------------
class EKYCData(APIView):
    authentication_classes = AUTH_CLASSES

    def post(self, request, *args, **kwargs):
        logger.error("EKYC request payload -- %s", request.data, extra=_log_extra())

        auth_error = _validate_api_key(request, "EKYC")
        if auth_error:
            return auth_error

        try:
            request_body = request.data
            if "kek" not in request_body:
                logger.error("EKYC kek is mandatory", extra=_log_extra())
                return _unauthorized("Missing kek in payload")
            if "cipherText" not in request_body:
                logger.error("EKYC cipher is missing in body", extra=_log_extra())
                return _unauthorized("Missing ciphertext in payload")

            plaintext = _decrypt_ekyc_payload(request_body)
            logger.error("EKYC Decrypted Payload - %s", plaintext, extra=_log_extra())

            try:
                ekyc_obj = EKYCDetails.objects.get(ekyc_ref_no=plaintext["trackingId"])
            except (EKYCDetails.DoesNotExist, KeyError) as exc:
                logger.error("EKYC no tracking id or missing - %s", exc, extra=_log_extra())
                return Response(data={"error": "Invalid or missing tracking ID"}, status=404)

            if ekyc_obj.ekyc_status == "SUCCESS" and "ekyc_body_details" in (ekyc_obj.ekyc_details or {}):
                logger.error("EKYC data exists and is success", extra=_log_extra())
                return Response(data=SUCCESS_PAYLOAD, status=200)

            ekyc_json = ekyc_obj.ekyc_details or {}
            ekyc_json.update({"ekyc_body_details": plaintext})
            ekyc_obj.ekyc_details = ekyc_json
            ekyc_obj.ekyc_status = "SUCCESS"
            ekyc_obj.save()

            product_code = _product_code_from_ref(plaintext.get("trackingId"))
            if product_code:
                digital_obj = _resolve_digital_by_ekyc(ekyc_obj, product_code)
                _invoke_whatsapp_bypass(
                    _phone_from_digital(digital_obj),
                    "Proceed",
                    log_prefix="EKYC message bypass user input",
                )
            else:
                logger.error(
                    "EKYC unsupported or missing product code in trackingId",
                    extra=_log_extra(),
                )
            return Response(data=SUCCESS_PAYLOAD, status=200)

        except Exception as exc:
            logger.error(
                "EKYC exception %s at line %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(),
            )
            return Response(data={"error": "Internal server error"}, status=500)


class VKYCStatus(APIView):
    authentication_classes = AUTH_CLASSES

    def post(self, request, *args, **kwargs):
        logger.error("VKYC status payload = %s", request.data, extra=_log_extra())

        auth_error = _validate_api_key(
            request, "VKYC status", invalid_message="Invalid key"
        )
        if auth_error:
            return auth_error

        try:
            request_body = request.data
            try:
                *_, plaintext_dict = result_dict["status_vkyc"](
                    request_body=request_body, aad=None
                )
                logger.error(
                    "VKYC status Decrypted Payload - %s",
                    plaintext_dict,
                    extra=_log_extra(),
                )
            except Exception as exc:
                logger.error("VKYC status Decryption error - %s", exc, extra=_log_extra())
                return Response(data={"error": "Decryption Failed"}, status=400)

            try:
                vkyc_obj = VKYCDetails.objects.get(vkyc_ref_no=plaintext_dict["leadId"])
            except (VKYCDetails.DoesNotExist, KeyError) as exc:
                logger.error("VKYC status no tracking id error - %s", exc, extra=_log_extra())
                return Response(data={"error": "Invalid Tracking ID"}, status=401)

            vkyc_text = vkyc_obj.vkyc_json_dump or {}
            vkyc_text.update({"vkys_status_incoming": plaintext_dict})
            vkyc_obj.vkyc_json_dump = vkyc_text
            incoming_status = plaintext_dict["status"]
            vkyc_obj.vkyc_status = incoming_status
            vkyc_obj.save()

            if incoming_status in VKYC_RETRY_STATUSES or incoming_status == VKYC_APPROVED_STATUS:
                ref_id = plaintext_dict.get("trackingId") or plaintext_dict.get("leadId")
                product_code = _product_code_from_ref(ref_id)
                digital_obj = _resolve_digital_by_vkyc(vkyc_obj, product_code)
                phone_number = _phone_from_digital(digital_obj)

            # if incoming_status in VKYC_RETRY_STATUSES:
            #     try:
            #         vkyc_url = _regenerate_vkyc_link(digital_obj)
            #         response = _send_whatsapp_text(
            #             phone_number, _build_vkyc_retry_message(vkyc_url, product_code)
            #         )
            #         logger.error(
            #             "VKYC status retry link sent, WA response: %s",
            #             response,
            #             extra=_log_extra(),
            #         )
            #     except Exception as exc:
            #         logger.error(
            #             "VKYC status regenerate link failed - %s at line %s",
            #             exc,
            #             _exception_lineno(),
            #             extra=_log_extra(),
            #         )
            #     return Response(data=SUCCESS_PAYLOAD, status=200)

            if incoming_status != VKYC_APPROVED_STATUS:
                logger.error(
                    "VKYC status not approved %s",
                    incoming_status,
                    extra=_log_extra(),
                )
                return Response(data={"status": "Success"}, status=200)

            message_body = "Your Video KYC is successfully completed/approved."
            response = _send_whatsapp_text(phone_number, message_body, preview_url=False)
            logger.error(
                "VKYC status function end, WA response: %s",
                response,
                extra=_log_extra(),
            )
            return Response(data=SUCCESS_PAYLOAD, status=200)

        except Exception as exc:
            logger.error(
                "VKYC status exception %s - line no- %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(),
            )
            return Response(data={"error": "internal server error"}, status=500)


class VKYCData(APIView):
    authentication_classes = AUTH_CLASSES

    def post(self, request, *args, **kwargs):
        logger.error("VKYCData payload -- %s", request.data, extra=_log_extra())

        auth_error = _validate_api_key(request, "VKYCData")
        if auth_error:
            return auth_error

        try:
            request_body = request.data
            logger.error("VKYCData Payload - %s", request_body, extra=_log_extra())

            *_, plaintext_dict = result_dict["status_vkyc"](
                request_body=request_body, aad=None
            )
            logger.error(
                "VKYCData Decrypted Payload - %s",
                plaintext_dict,
                extra=_log_extra(),
            )

            try:
                vkyc_obj = VKYCDetails.objects.get(
                    vkyc_ref_no=plaintext_dict["trackingId"]
                )
            except (VKYCDetails.DoesNotExist, KeyError) as exc:
                logger.error("VKYCData Invalid Tracking ID - %s", exc, extra=_log_extra())
                return Response(data={"error": "Invalid Tracking ID"}, status=401)

            if vkyc_obj.vkyc_status == "SUCCESS" and "vkyc_body_details" in (vkyc_obj.vkyc_json_dump or {}):
                logger.error("VKYCData exists and is success", extra=_log_extra())
                return Response(data=SUCCESS_PAYLOAD, status=200)

            vkyc_obj.vkyc_status = "SUCCESS"
            vkyc_text = vkyc_obj.vkyc_json_dump or {}
            vkyc_text.update({"vkyc_body_details": plaintext_dict})
            vkyc_obj.vkyc_json_dump = vkyc_text
            vkyc_obj.save()

            try:
                product_code = _product_code_from_ref(plaintext_dict["trackingId"])
                digital_obj = _resolve_digital_by_vkyc(vkyc_obj, product_code)
                bypass_text = _get_product_bypass_text(product_code)
            except Exception as exc:
                logger.error("VKYCData dsa objects not found - %s", exc, extra=_log_extra())
                return Response(data={"error": "Invalid Tracking ID"}, status=401)

            phone_number = _phone_from_digital(digital_obj)
            _invoke_whatsapp_bypass(
                phone_number,
                bypass_text,
                log_prefix="VKYCData message bypass user input",
            )
            logger.error("VKYCData data collected", extra=_log_extra())
            return Response(data=SUCCESS_PAYLOAD, status=200)

        except Exception as exc:
            logger.error(
                "VKYCData exception %s - %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(),
            )
            return Response(data={"error": "internal server error"}, status=400)


# ---------------------------------------------------------------------------
# Account opening
# ---------------------------------------------------------------------------
class AccountOpeningStatusAPI(APIView):
    authentication_classes = AUTH_CLASSES

    def post(self, request, *args, **kwargs):
        logger.error("AccountOpeningStatusAPI body - %s", request.data, extra=_log_extra())
        logger.error(
            "AccountOpeningStatusAPI headers - %s",
            request.headers,
            extra=_log_extra(),
        )

        auth_error = _validate_api_key(request, "AccountOpeningStatusAPI")
        if auth_error:
            return auth_error

        kek = request.headers.get("kek")
        if not kek:
            logger.error("AccountOpeningStatusAPI kek not passed", extra=_log_extra())
            return _unauthorized("Missing kek in headers")

        try:
            request_body = request.data
            if "RequestEncryptedValue" not in request_body:
                logger.error(
                    "AccountOpeningStatusAPI RequestEncryptedValue is missing in body",
                    extra=_log_extra(),
                )
                return _unauthorized("Missing RequestEncryptedValue in payload")

            plaintext, decrypted_data = _decrypt_rsa_aes_payload(
                kek, request_body["RequestEncryptedValue"]
            )
            logger.error(
                "AccountOpeningStatusAPI Decrypted Payload - %s",
                plaintext,
                extra=_log_extra(),
            )

            try:
                scheme_type = plaintext["details"]["accountDtls"]["schemeType"]
                digital_obj = _resolve_digital_by_lead(plaintext["leadID"], scheme_type)
            except Exception as exc:
                logger.error(
                    "AccountOpeningStatusAPI Invalid Lead ID error -- %s",
                    exc,
                    extra=_log_extra(),
                )
                return Response(
                    data={"error": f"Invalid Lead ID - {plaintext.get('leadID')}"},
                    status=401,
                )

            _update_or_create_account_details(digital_obj, plaintext, decrypted_data)

            webhook_ns = _exec_whatsapp_webhook_namespace()

            phone_number = _phone_from_digital(digital_obj)
            scheme_code = str(plaintext["details"]["accountDtls"]["schemeCode"])
            scheme_type = str(plaintext["details"]["accountDtls"]["schemeType"])
            reply_buttons = {"main menu": "Main Menu"}

            if scheme_type == SCHEME_TYPE_SBA:
                text = _build_sba_success_message(digital_obj, plaintext, scheme_code)
            elif scheme_type == SCHEME_TYPE_TDA:
                text = _build_tda_success_message(digital_obj, plaintext)
            else:
                text = "Your account has been opened successfully."

            # api_key is unused by sendWhatsAppQuickReplyMessage (auth uses IBM gateway headers).
            response = webhook_ns["sendWhatsAppQuickReplyMessage"](
                None, "null", reply_buttons, "", text, "", phone_number,
            )
            logger.error(
                "AccountOpeningStatusAPI Response from WhatsApp API: %s",
                response,
                extra=_log_extra(),
            )

            try:
                if scheme_type == SCHEME_TYPE_SBA:
                    aof_res = result_dict["DSAUploadAOF"](digital_obj.application_id)
                    logger.error(
                        "AccountOpeningStatusAPI AOF upload response Digital Savings Account- %s",
                        aof_res,
                        extra=_log_extra(),
                    )
                elif scheme_type == SCHEME_TYPE_TDA:
                    aof_res = result_dict["DFDUploadAOF"](digital_obj.application_id)
                    logger.error(
                        "AccountOpeningStatusAPI AOF upload response Digital Fixed Deposit- %s",
                        aof_res,
                        extra=_log_extra(),
                    )
            except Exception as exc:
                logger.error(
                    "AccountOpeningStatusAPI AOF upload exception %s",
                    exc,
                    extra=_log_extra(),
                )
                return Response(data={"error": "Internal server error"}, status=500)

            try:
                if scheme_type == SCHEME_TYPE_TDA:
                    fd_res = result_dict["DFDUploadFDAdvice"](
                        plaintext["details"]["accountNumber"], digital_obj
                    )
                    logger.error(
                        "AccountOpeningStatusAPI FDAdvice upload response - %s",
                        fd_res,
                        extra=_log_extra(),
                    )
            except Exception as exc:
                logger.error(
                    "AccountOpeningStatusAPI FDAdvice upload exception %s",
                    exc,
                    extra=_log_extra(),
                )
                return Response(data={"error": "Internal server error"}, status=500)

            return Response(data=SUCCESS_PAYLOAD, status=200)

        except Exception as exc:
            logger.error(
                "AccountOpeningStatusAPI payment exception %s at line %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(),
            )
            return Response(data={"error": "Internal server error"}, status=500)


# ---------------------------------------------------------------------------
# Captcha
# ---------------------------------------------------------------------------
class getCaptchaImageAPI(APIView):
    authentication_classes = AUTH_CLASSES
    permission_classes = (IsAuthenticated,)

    def _mint_challenge(self, request):
        """
        Mint a captcha bound to auth:{username}.

        GET/POST do not need body/query user_id; Profile binding is validated
        later on validateCaptchaAPI.
        """
        owner = _authenticated_captcha_subject(request)
        _, captcha_image_url = create_captcha_challenge(owner_subject=owner or "")
        return captcha_image_url

    def get(self, request, *args, **kwargs):
        response = {"status": 500}
        try:
            response["captcha_image"] = self._mint_challenge(request)
            response["status"] = 200
            response["status_message"] = "Request processed successfully."
        except Exception as exc:
            logger.error(
                "getCaptchaImageAPI GET: %s at %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(user_id=getattr(request.user, "username", "")),
            )
        return Response(data=response)

    def post(self, request, *args, **kwargs):
        response = {"status": 500}
        try:
            # Same as GET: bind to authenticated principal only.
            response["captcha_image"] = self._mint_challenge(request)
            response["status"] = 200
            response["status_message"] = "Request processed successfully."
        except Exception as exc:
            logger.error(
                "getCaptchaImageAPI POST: %s at %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(user_id=getattr(request.user, "username", "")),
            )
        return Response(data=response)


class CaptchaChallengeImageAPI(APIView):
    """Serve a freshly generated captcha JPEG from cache (no static pool)."""

    authentication_classes = ()
    permission_classes = ()

    def get(self, request, captcha_id, *args, **kwargs):
        image_bytes = get_captcha_image_bytes(str(captcha_id).upper())
        if not image_bytes:
            return HttpResponseNotFound("Captcha expired or not found")
        return HttpResponse(image_bytes, content_type="image/jpeg")


class validateCaptchaAPI(APIView):
    authentication_classes = AUTH_CLASSES
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        response = {"status": 500}
        try:
            data = _parse_json_string_payload(request)
            captcha = data["captcha_value"]
            captcha_id = extract_captcha_id_from_url(data["captcha_image"])
            body_user_id = str(data.get("user_id") or "")

            # Same canonical subject as mint (auth:{username}).
            rate_limit_subject = _authenticated_captcha_subject(request)
            if not rate_limit_subject:
                return Response(
                    data={
                        "status": 401,
                        "status_message": "Authentication required.",
                    },
                    status=401,
                )

            # Profile updates only for a caller-bound user_id.
            profile_user_id = _verified_captcha_profile_user_id(
                request, body_user_id
            )
            if not profile_user_id:
                response["status"] = 403
                response["status_message"] = (
                    "user_id is not bound to the authenticated caller."
                )
                return Response(data=response, status=403)

            # Check lock before owner: locking deletes the challenge, so an
            # owner miss must not hide the max-limit response.
            if is_captcha_validation_locked(
                user_id=rate_limit_subject, captcha_id=captcha_id
            ):
                response["status"] = 301
                response["status_message"] = CAPTCHA_MAX_LIMIT_MESSAGE
                return Response(data=response)

            challenge_owner = get_captcha_owner(captcha_id)
            if not challenge_owner or challenge_owner != rate_limit_subject:
                response["status"] = 403
                response["status_message"] = (
                    "Captcha challenge does not belong to caller."
                )
                return Response(data=response, status=403)

            bot_obj = Bot.objects.get(pk=DEFAULT_BOT_ID, is_deleted=False)
            user = Profile.objects.filter(
                user_id=profile_user_id, bot=bot_obj
            ).first()
            if not user:
                raise ValueError(f"Profile not found for user_id={profile_user_id}")

            if verify_captcha(captcha_id, captcha, consume=True):
                clear_captcha_attempts(
                    user_id=rate_limit_subject, captcha_id=captcha_id
                )
                save_data(
                    user,
                    json_data={"captcha_validated": "true"},
                    src="None",
                    channel="WhatsApp",
                    bot_id=DEFAULT_BOT_ID,
                    is_cache=True,
                )
                response["status"] = 200
                response["status_message"] = "Request processed successfully."
            else:
                locked = record_invalid_captcha_attempt(
                    user_id=rate_limit_subject, captcha_id=captcha_id
                )
                save_data(
                    user,
                    json_data={"captcha_validated": "false"},
                    src="None",
                    channel="WhatsApp",
                    bot_id=DEFAULT_BOT_ID,
                    is_cache=True,
                )
                response["status"] = 301
                if locked:
                    response["status_message"] = CAPTCHA_MAX_LIMIT_MESSAGE
        except Exception as exc:
            logger.error(
                "validateCaptchaAPI: %s at %s",
                exc,
                _exception_lineno(),
                extra=_log_extra(user_id=getattr(request.user, "username", "")),
            )
        return Response(data=response)


# ---------------------------------------------------------------------------
# URL-facing view callables
# ---------------------------------------------------------------------------
getCaptchaImage = getCaptchaImageAPI.as_view()
serveCaptchaChallenge = CaptchaChallengeImageAPI.as_view()
validateCaptcha = validateCaptchaAPI.as_view()
AccountOpeningStatus = AccountOpeningStatusAPI.as_view()
vkycData = VKYCData.as_view()
vkycStatus = VKYCStatus.as_view()
ekycData = EKYCData.as_view()
