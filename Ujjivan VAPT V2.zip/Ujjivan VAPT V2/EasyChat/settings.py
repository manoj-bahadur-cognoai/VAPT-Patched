import os

import json

from urllib.parse import urlparse

from elasticsearch import Elasticsearch

from corsheaders.defaults import default_headers

from DeveloperConsoleApp.utils_project_dirs import *

from decouple import config

import redis

from EncryptDecryptVars.update_env_vars import update_env_vars

update_env_vars()

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = config('SECRET_KEY')

DEBUG = config('DEBUG', default=False, cast=bool)

# If the project is running on production environment then this needs to be set as False
IS_UAT_DEPLOYMENT = config('IS_UAT_DEPLOYMENT', default=False, cast=bool)

EASYCHAT_VERSION = "7.0"

# APPEND DATE AFTER FREEZE

EASYCHAT_DATE_OF_RELEASE = config('EASYCHAT_DATE_OF_RELEASE')

EASYCHAT_DOMAIN = config('EASYCHAT_DOMAIN')

EASYCHAT_HOST_URL = "https://" + EASYCHAT_DOMAIN

IS_RDS_ENABLED = config('IS_RDS_ENABLED', default=False, cast=bool)

IS_AWS_CLIENT_MICROSERVICE_ENABLED = config(
    'IS_AWS_CLIENT_MICROSERVICE_ENABLED', default=False, cast=bool)

EASYCHAT_DB_SCHEMA_NAME = config('EASYCHAT_DB_SCHEMA_NAME')

# This flag will load the QuickSight analytics page instead of our analytics page.
ENABLE_QUICKSIGHT_ANALYTICS = False

# If this flag is set to True, message_received and bot_response will be stored in encrypted form in MISDashboard
ENABLE_MISDASHBOARD_DATA_ENCRYPTION = False

ALLOWED_HOSTS = [EASYCHAT_DOMAIN, "127.0.0.1", "0.0.0.0", "apisit.ujjivansfb.in"]

MASKING_PII_DATA_OTP_EMAIL = []

DEFAULT_AUTO_FIELD = 'django.db.models.AutoField'

CSRF_FAILURE_VIEW = 'EasyChatApp.views.csrf_failure'

SESSION_COOKIE_SAMESITE = "Strict"

#VAPT Missing Security headers fixex append_slash = false

APPEND_SLASH =  False

# SESSION_COOKIE_PATH = config("COOKIE_PATH")

CSRF_USE_SESSIONS = True

#Custom Change
USE_X_FORWARDED_HOST = True

# Lowercase to match nginx X-Forwarded-Proto (exact match; else SSL redirect loops).
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

CRONJOB_REPORT_EMAIL = [
    'exotel1@ujjivan.com',
]

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.path.join(
    BASE_DIR, 'google_translate_api.json')

LOCATION_CACHE_IP = config('LOCATION_CACHE_IP')

LOCATION_CACHE_PORT = config('LOCATION_CACHE_PORT')

AZURE_CHAT_PDF_SERVICE_DETAILS = {
    "COGNITIVE_SEARCH_KEY": config('COGNITIVE_SEARCH_KEY'),
    "COGNITIVE_SEARCH_SERVICE_NAME": config('COGNITIVE_SEARCH_SERVICE_NAME'),
    "BLOB_STORAGE_KEY": config('BLOB_STORAGE_KEY'),
    "BLOB_STORAGE_ACCOUNT_NAME": config('BLOB_STORAGE_ACCOUNT_NAME'),
    "FORM_RECOGNIZER_KEY": config('FORM_RECOGNIZER_KEY'),
    "FORM_RECOGNIZER_SERVICE_NAME": config('FORM_RECOGNIZER_SERVICE_NAME'),
    "AZURE_OPENAI_SERVICE_KEY": config('AZURE_OPENAI_SERVICE_KEY'),
    "AZURE_OPENAI_SERVICE_NAME": config('AZURE_OPENAI_SERVICE_NAME'),
    "AZURE_OPENAI_API_VERSION": config('AZURE_OPENAI_API_VERSION'),
    "AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME": config('AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME'),
    "AZURE_OPENAI_TRAINING_DEPLOYMENT_NAME": config('AZURE_OPENAI_TRAINING_DEPLOYMENT_NAME'),
    "AZURE_OPENAI_TRAINING_MODEL_NAME": config('AZURE_OPENAI_TRAINING_MODEL_NAME'),
}



# Whitelisted Referer URL's
ALLOWED_REFERER = ['https://chatbot.ujjivansfb.bank.in', 'https://sfbuat.ujjivansfb.bank.in', 'https://uat-sfb.ujjivansfb.bank.in', 'https://pre-prod-sfb.ujjivsnsfb.bank.in']


#Netcore-API-Gateway WhatsApp Settings
NETCORE_WHATSAPP_JWT = config('NETCORE_WHATSAPP_JWT')
NETCORE_WHATSAPP_API_URL = config('NETCORE_WHATSAPP_API_URL')
IBM_APIGW_CLIENT_ID = config('IBM_APIGW_CLIENT_ID')
IBM_APIGW_CLIENT_SECRET = config('IBM_APIGW_CLIENT_SECRET')

# OpenAI Service Keys
OPENAI_SERVICE_KEY = config('OPENAI_SERVICE_KEY')
OPENAI_GPT4_SERVICE_KEY = config('OPENAI_GPT4_SERVICE_KEY')


# ALLOWED_HOSTS = ["*"]

if DEBUG == False:

    # Non-exempt views get X-Frame-Options. /chat/index/ stays @xframe_options_exempt
    # so external bank sites can embed it; clickjacking there uses CSP frame-ancestors
    # (SecurityHeaderMiddleware + ALLOWED_EMBED_ORIGINS), not X-Frame-Options.
    X_FRAME_OPTIONS = 'SAMEORIGIN'

    XS_SHARING_ALLOWED_METHODS = ['POST', 'GET']

    if EASYCHAT_DOMAIN in ["easychat-dev.allincall.in", "easychat-uat.allincall.in", "easychat.allincall.in",
                           "easychat-stag.allincall.in"]:

        CORS_ORIGIN_ALLOW_ALL = True

        CORS_ORIGIN_WHITELIST = [
            EASYCHAT_HOST_URL, "https://accounts.google.com"]

        CORS_ALLOW_METHODS = ['GET', 'POST']

        EASYCHAT_SHOW_CONSOLE_LOGS = True

    else:

        CORS_ORIGIN_ALLOW_ALL = False

        CORS_ORIGIN_WHITELIST = [EASYCHAT_HOST_URL, "https://sfbuat.ujjivansfb.bank.in", "https://uat-sfb.ujjivansfb.bank.in", "https://pre-prod-sfb.ujjivsnsfb.bank.in"]

        CORS_ALLOW_METHODS = ['GET', 'POST']

        EASYCHAT_SHOW_CONSOLE_LOGS = False

    
    BLOCKED_URLPATTERNS = []

    CSRF_COOKIE_SECURE = True

    CSRF_COOKIE_HTTPONLY = True

    CSRF_COOKIE_DOMAIN = EASYCHAT_DOMAIN

    CSRF_COOKIE_AGE = 86400  # 24 Hours

    SESSION_COOKIE_SECURE = True

    # HTTPS is the confidentiality control. The proxy terminates
    # TLS (see SECURE_PROXY_SSL_HEADER); these flags redirect plain HTTP
    # and tell browsers to keep using HTTPS, including subdomains.
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True

    SESSION_COOKIE_DOMAIN = EASYCHAT_DOMAIN

    SESSION_EXPIRE_AT_BROWSER_CLOSE = True

    ENABLE_IP_TRACKING = True

    SESSION_COOKIE_HTTPONLY = True

    CONFIG_FILE = open(os.path.join(BASE_DIR, 'files/') +
                       "livechat_integrations/config.json", 'r')

    JSON_DATA = json.load(CONFIG_FILE)
    
    SESSION_COOKIE_SAMESITE = 'Strict' #Custom for VAPT

    CSRF_COOKIE_SAMESITE = 'Strict' #Custom for VAPT

    CSRF_COOKIE_HTTPONLY = True #Custom for VAPT

    SESSION_COOKIE_HTTPONLY = True  #Custom for VAPT

    CSRF_COOKIE_SAMESITE_FORCE_PROTECTION = True

    # Django 3.2 expects hostnames (no scheme). Needed when the browser
    # Referer host differs from request.get_host() behind the proxy, or when
    # users hit an alternate Ujjivan host that is not EASYCHAT_DOMAIN.
    # Without this, SessionAuthentication POSTs (e.g. /chat/bots-details/)
    # fail with: CSRF Failed: Referer checking failed - ... trusted origins.
    _csrf_trusted_hosts = [EASYCHAT_DOMAIN]
    for _origin in ALLOWED_REFERER:
        _host = urlparse(_origin).netloc or _origin
        if _host:
            _csrf_trusted_hosts.append(_host)
    CSRF_TRUSTED_ORIGINS = list(dict.fromkeys(_csrf_trusted_hosts))

    if JSON_DATA['ms_dynamics']['is_integrated']:
        CSRF_COOKIE_HTTPONLY = False
        CSRF_COOKIE_SAMESITE = 'None'
        CSRF_TRUSTED_ORIGINS = list(dict.fromkeys(
            CSRF_TRUSTED_ORIGINS + JSON_DATA['ms_dynamics']['CSRF_TRUSTED_ORIGINS'] + [EASYCHAT_DOMAIN]
        ))
        SESSION_SAVE_EVERY_REQUEST = True
        SESSION_COOKIE_SAMESITE = 'None'
        SESSION_COOKIE_HTTPONLY = False

else:

    CORS_ORIGIN_ALLOW_ALL = True

    ENABLE_IP_TRACKING = False

    X_FRAME_OPTIONS = 'ALLOWALL'

    BLOCKED_URLPATTERNS = []

    CRONJOB_REPORT_EMAIL = []

    EASYCHAT_SHOW_CONSOLE_LOGS = True

CORS_ALLOW_HEADERS = list(default_headers) + [
    'X-AccessToken'
]

# Origins allowed to postMessage into chatbot iframes (VAPT: unvalidated cross-origin DOM XSS)
# and to embed the chat widget (VAPT clickjacking / CSP frame-ancestors).
# Must include every parent site that embeds the bot in an iframe, plus the bot host itself.
# Chatbot JS also always allows window.location.origin (same bot URL domain).
# Do not use "*". Keep in sync with sites that load the chatbot embed.
POSTMESSAGE_ALLOWED_ORIGINS = list(globals().get('CORS_ORIGIN_WHITELIST', [EASYCHAT_HOST_URL]))
if EASYCHAT_HOST_URL not in POSTMESSAGE_ALLOWED_ORIGINS:
    POSTMESSAGE_ALLOWED_ORIGINS.append(EASYCHAT_HOST_URL)
for _referer in ALLOWED_REFERER:
    _normalized = (_referer or '').rstrip('/')
    if _normalized and _normalized != '*' and _normalized not in POSTMESSAGE_ALLOWED_ORIGINS:
        POSTMESSAGE_ALLOWED_ORIGINS.append(_normalized)
# Explicitly drop any accidental wildcard; normalize trailing slashes
POSTMESSAGE_ALLOWED_ORIGINS = [o.rstrip('/') for o in POSTMESSAGE_ALLOWED_ORIGINS if o and o != '*']
# Alias used by VAPT remediations / docs (same allow-list)
ALLOWED_EMBED_ORIGINS = POSTMESSAGE_ALLOWED_ORIGINS

EASYCHAT_SESSION_AGE = 1800  # 30 min inactivity

ENABLE_AUTO_LOGOUT_SESSION = True

# We do not use this variable to whitelist ip addresses anymore. You can add ip addresses in DeveloperConsoleConfig table's whitelisted_ip_addresses column from django admin to whitelist ip address.
WHITELISTED_IP_ADDRESSES = []

WHITELISTED_URLPATTERNS = []

WHITELISTED_IP_FOR_BLOCKED_URLS = []

# Time interval to update bot suggestion list
UPDATE_SUGGESTION_LIST_FREQUENCY = 300

# Cobrowsing App Settings

WRONG_PASSWORD_LOCKIN_TIMEOUT = 600  # mins

WRONG_PASSWORD_ATTEMPTS = 5

# time interval in seconds after which processors execution is stoped
EASYCHAT_PROCESSORS_MAX_RUNTIME_LIMIT = 28

LIVECHATAPP_PROCESSORS_MAX_RUNTIME_LIMIT = 5

ALLOW_SIMULTANEOUS_LOGIN = False

EASYASSIST_HOST_PROTOCOL = "https"

EASYASSISTAPP_HOST = EASYCHAT_HOST_URL

EASYASSISTSALESFOCEAPP_HOST = EASYCHAT_HOST_URL

EASYCHAT_ADMIN_USER = ["admin@ujjivan.com"]

PARAPHRASE_NLP_CORE = "en_core_web_sm"

SECURE_BROWSER_XSS_FILTER = True

QUERY_API_TIMEOUT = 30  # For automated flow testing platform

DEVELOPMENT = DEBUG

# Default Django/Redis cache TTL for static lookups (Bot, Channel, Language, etc.)
CACHE_TIME = 86400  # 24 hours

# Netcore WhatsApp webhook thread-pool size (batch fan-out). Tunable per env.
WHATSAPP_WEBHOOK_MAX_WORKERS = 10

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'EasyChatApp',
    'rest_framework',
    'corsheaders',
    'oauth2_provider',
    'django_ace',
    'logtailer',
    'channels',
    'EasySearchApp',
    'EasyTMSApp',
    'LiveChatApp',
    'EasyAssistApp',
    'AutomatedAPIApp',
    'AuditTrailApp',
    'CampaignApp',
    'DeveloperConsoleApp',
    'django_saml2_auth',
    'django_crontab',
    'EasyAssistSalesforceApp',
    'TestingApp',
    'OAuthApp',
    'CognoMeetApp',
    'CustomApp',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django_user_agents.middleware.UserAgentMiddleware',
    'EasyChatApp.middleware.IPAddressCheckMiddleware',
    'EasyChatApp.middleware.RestrictSessionMiddleware',
    'EasyChatApp.middleware.AutoLogout',
    'EasyChatApp.middleware.SecurityHeaderMiddleware',
]


ROOT_URLCONF = 'EasyChat.urls'


AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {
            'min_length': 10,
        }
    },
]


TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'EasyChatApp.context_processors.is_console_logs',
                'EasyChatApp.context_processors.is_quicksight_analytics_enabled',
                'EasyChatApp.context_processors.is_cookies_attributes_enabled',
                'EasyChatApp.context_processors.postmessage_allowed_origins',
                'EasyChatApp.context_processors.google_maps_api_key',
                'DeveloperConsoleApp.context_processors.get_livechat_config_obj',
                'DeveloperConsoleApp.context_processors.get_easychat_config_obj',
                'DeveloperConsoleApp.context_processors.get_developer_console_config_obj',
                'DeveloperConsoleApp.context_processors.get_cognodesk_console_config_obj',
                'DeveloperConsoleApp.context_processors.get_cobrowse_console_config_obj',
                'DeveloperConsoleApp.context_processors.get_cognomeet_console_config_obj',
            ],
            'builtins': [
                'LiveChatApp.templatetags.random_numbers',
            ],
        },
    },
]

WSGI_APPLICATION = 'EasyChat.wsgi.application'

AUTH_USER_MODEL = "EasyChatApp.User"

KAFKA_CONFIG = {
    'bootstrap_servers': config('KAFKA_BOOTSTRAP_SERVER'),
    'livechat_report_topic': 'LiveChatReportTopic',
}


# Database
# https://docs.djangoproject.com/en/1.11/ref/settings/#databases

if DEBUG:
    # Sqlite Database Configuration
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
        }
    }

else:

    if IS_RDS_ENABLED == True:
        # RDS Configuration
        DATABASES = {
            'default': {
                'ENGINE': 'django.db.backends.postgresql_psycopg2',
                'OPTIONS': {
                    'options': '-c search_path=' + EASYCHAT_DB_SCHEMA_NAME
                },
                'NAME': config('DATABASE_NAME'),
                'USER': config('DATABASE_USER'),
                'PASSWORD': config('DATABASE_PASSWORD'),
                'HOST': config('DATABASE_HOST'),
                'PORT': config('DATABASE_PORT', cast=int),
            }
        }

    else:
        DATABASES = {
            'default': {
                'ENGINE': 'django.db.backends.postgresql_psycopg2',
                'NAME': config('DATABASE_NAME'),
                'USER': config('DATABASE_USER'),
                'PASSWORD': config('DATABASE_PASSWORD'),
                'HOST': config('DATABASE_HOST'),
                'PORT': config('DATABASE_PORT', cast=int),
            }
        }



REDIS_LOCATION = f"rediss://{LOCATION_CACHE_IP}:{LOCATION_CACHE_PORT}/1"

CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': REDIS_LOCATION,
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient'
        },
        'TIMEOUT': CACHE_TIME,
        'KEY_PREFIX' : '',
        'VERSION': 1,
    }
}


    #CACHES = {
    #    'default': {
    #        'BACKEND': 'django.core.cache.backends.memcached.PyMemcacheCache',
    #        'LOCATION': f'{LOCATION_CACHE_IP}:{LOCATION_CACHE_PORT}',
    #    }
    #}

# Password validation
# https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/1.11/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Kolkata'

USE_I18N = True

USE_L10N = True

USE_TZ = True

"""
EasyChat Sensitive Tag
"""

EASYCHAT_SENSITIVE_REGEX = r"(<easychat:sensitive>)(.*?)(<\/easychat:sensitive>)"

EASYCHAT_LEMMATIZER_REQUIRED = True

EASYCHAT_DEFAULT_CHAT_PAGE = "EasyChatApp/theme2.html"

EASYCHAT_DEFAULT_MAIN_PAGE = "EasyChatApp/theme2_bot.html"

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.11/howto/static-files/

STATIC_URL = '/static/'

# Insecure Cookie Attributes vapt

# VAPT

COOKIE_SECURE = config('COOKIE_SECURE', default=True, cast=bool)

COOKIE_SAMESITE = config('COOKIE_SAMESITE', default='Strict')

COOKIE_PATH = config('COOKIE_PATH', default='/chat/')

STATIC_ROOT = os.path.join(BASE_DIR, 'static/')

MEDIA_ROOT = os.path.join(BASE_DIR, 'files/')

SECURE_MEDIA_ROOT = os.path.join(BASE_DIR, 'secured_files/')

MEDIA_URL = '/files/'

IMAGE_UPLOAD_PATH = "images"

EASYCHAT_ROOT = os.path.join(BASE_DIR, 'EasyChat/')

LIVECHAT_ROOT = os.path.join(BASE_DIR, 'LiveChatApp/')

EASYCHAT_PRIVATE_KEY_PATH = os.path.join(BASE_DIR, 'EasyChatApp/')

ELASTIC_SEARCH_OBJ = Elasticsearch(
    ['https://elasticsearch.allincall.in:443/'], http_auth=('elastic', 'AllinCall@123'))

if DEBUG:
    ELASTIC_SEARCH_OBJ = Elasticsearch(
        [{'host': 'localhost', 'port': 9200}], verify_certs=True)

APP_LOG_FILENAME = os.path.join(BASE_DIR, 'log/app.log')

ERROR_LOG_FILENAME = os.path.join(BASE_DIR, 'log/error.log')

SENSITIVE_LOG_FILENAME = os.path.join(BASE_DIR, 'log/sensitive.log')

LOGFILE_SIZE = 20 * 1024 * 1024

LOGFILE_COUNT = 10

LOGFILE_APP = 'EasyChatApp'

CAMPAIGNAPP_LOGFILE = 'CampaignApp'

DEVELOPER_CONSOLE_APP_LOGFILE = 'DeveloperConsoleApp'

EASYSEARCHAPP_LOGFILE = 'EasySearchApp'

EASYTMSAPP_LOGFILE = 'EasyTMSApp'

LIVECHATAPP_LOGFILE = "LiveChatApp"

EASYASSISTAPP_LOGFILE = "EasyAssistApp"

COGNOMEETAPP_LOGFILE = "CognoMeetApp"

EASYASSISTSALESFORCEAPP_LOGFILE = 'EasyAssistSalesforceApp'

AUTOMATEDAPIINTEGRATION_LOGFILE = 'AutomatedAPIApp'

TESTINAPP_LOGFILE = 'TestingApp'

AUDITTRAILAPP_LOGFILE = 'AuditTrailApp'

OAUTHAPP_LOGFILE = 'OAuthApp'

CUSTOMAPP_LOGFILE = 'CustomApp'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'easychat_standard': {
            'format': "[%(asctime)s] %(levelname)s [%(filename)s:%(lineno)s] [%(AppName)s] [%(channel)s] [%(bot_id)s] %(message)s",
            'datefmt': "%d-%b-%Y %H:%M:%S"
        },
        'standard': {
            'format': "[%(asctime)s] %(levelname)s [%(filename)s:%(lineno)s] [%(AppName)s] %(message)s",
            'datefmt': "%d-%b-%Y %H:%M:%S"
        }
    },
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        },
        'custom_filter': {
            '()': 'EasyChatApp.log_filter.SensitiveDataFilter'
        }
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler'
        },
        'mail_admins': {
            'level': 'INFO',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        },
        'easychat_applog': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': APP_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'easychat_standard',
        },
        'easychat_errorlog': {
            'level': 'ERROR',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': ERROR_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'easychat_standard',
        },
        'easychat_sensitivelog': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': SENSITIVE_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'easychat_standard',
            'filters': ['custom_filter']
        },
        'applog': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': APP_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'standard',
        },
        'errorlog': {
            'level': 'ERROR',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': ERROR_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'standard',
        },
        'sensitivelog': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': SENSITIVE_LOG_FILENAME,
            'maxBytes': LOGFILE_SIZE,
            'backupCount': LOGFILE_COUNT,
            'formatter': 'standard',
            'filters': ['custom_filter']
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'INFO',
            'propagate': True,
        },
        LOGFILE_APP: {
            'handlers': ['easychat_applog', 'easychat_errorlog', 'easychat_sensitivelog'],
            'level': 'INFO',
            'propagate': True,
        },
        CAMPAIGNAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        DEVELOPER_CONSOLE_APP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        EASYSEARCHAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        EASYTMSAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        LIVECHATAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        EASYASSISTAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        COGNOMEETAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        EASYASSISTSALESFORCEAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        AUTOMATEDAPIINTEGRATION_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        TESTINAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        AUDITTRAILAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        OAUTHAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        },
        CUSTOMAPP_LOGFILE: {
            'handlers': ['applog', 'errorlog'],
            'level': 'INFO',
            'propagate': True,
        }

    }
}

LOGTAILER_HISTORY_LINES = 50

LOGTAILER_LINES = 1000

GOOGLE_SEARCH_DEVELOPER_KEY = ""

GOOGLE_SEARCH_CUSTOM_SEARCH_KEY = ""

# Browser Maps key for chatbot location widget. Prefer env/Secrets Manager; do not hardcode in static JS.
GOOGLE_MAPS_API_KEY = config('GOOGLE_MAPS_API_KEY', default='')

REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    )
}


# LiveChat Requirements
ASGI_APPLICATION = 'EasyChat.routing.application'

CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [(config('CHANNEL_LAYERS_REDIS_HOST'), config('CHANNEL_LAYERS_REDIS_PORT', cast=int))],
            "capacity": 1500,
            "expiry": 10
        },
    },
}

redis_connection = redis.StrictRedis(host=config('CHANNEL_LAYERS_REDIS_HOST'), port=config('CHANNEL_LAYERS_REDIS_PORT', cast=int))

if DEBUG:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels_redis.core.RedisChannelLayer',
            'CONFIG': {
                "hosts": [('127.0.0.1', 6379)],
                "capacity": 1500,
                "expiry": 10
            },
        },
    }
    
    redis_connection = redis.StrictRedis(host='127.0.0.1', port=6379)
    

# Maximum size of POST request is currently 10MB.

DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

EMAIL_USE_TLS = True

EMAIL_HOST = config('EMAIL_HOST')

EMAIL_HOST_USER = config('EMAIL_HOST_USER')

EMAIL_HOST_PASSWORD = config("EMAIL_HOST_PASSWORD_GA")

EMAIL_CSM = config('EMAIL_CSM')

EMAIL_NOTIFICATIONS = config('EMAIL_NOTIFICATIONS')

SAML2_AUTH = {
    # Metadata is required, choose either remote url or local file path
    'METADATA_AUTO_CONF_URL': '[The auto(dynamic) metadata configuration URL of SAML2]',
    'METADATA_LOCAL_FILE_PATH': os.path.join(BASE_DIR, 'google-ldap.conf'),
    # Optional settings below
    # Custom target redirect URL after the user get logged in. Default to
    # /admin if not set. This setting will be overwritten if you have
    # parameter ?next= specificed in the login URL.
    'DEFAULT_NEXT_URL': '/chat/home',
    # Create a new Django user when a new user logs in. Defaults to True.
    'CREATE_USER': 'TRUE',
    'NEW_USER_PROFILE': {
        'USER_GROUPS': [],  # The default group name when a new user logs in
        'ACTIVE_STATUS': True,  # The default active status for new users
        'STAFF_STATUS': True,  # The staff status for new users
        'SUPERUSER_STATUS': False,  # The superuser status for new users
    },
    'ATTRIBUTES_MAP': {  # Change Email/UserName/FirstName/LastName to corresponding SAML2 userprofile attributes.
        'email': 'EmailID',
        'username': 'EmailID',
        'first_name': 'FirstName',
        'last_name': 'LastName',
    },
    'TRIGGER': {
        'CREATE_USER': 'EasyChatApp.utils.sso_pre_login_check',
        'BEFORE_LOGIN': 'EasyChatApp.utils.sso_pre_login_check',
    },
    # Custom URL to validate incoming SAML requests against
    'ASSERTION_URL': EASYCHAT_HOST_URL,
    # Populates the Issuer element in authn request
    'ENTITY_ID': EASYCHAT_HOST_URL + '/sso_auth/acs/',
    'NAME_ID_FORMAT': "None",  # Sets the Format property of authn NameIDPolicy element
    # Set this to True if you are running a Single Page Application (SPA) with
    # Django Rest Framework (DRF), and are using JWT authentication to
    # authorize client users
    'USE_JWT': False,
    # Redirect URL for the client if you are using JWT auth with DRF. See
    # explanation below
    'FRONTEND_URL': EASYCHAT_HOST_URL,
}

IS_REPORT_GENERATION_VIA_KAFKA_ENABLED = False

IS_FINGERPRINT_AUTHENTICATION_ENABLED = config(
    'ENABLE_FINGERPRINT_AUTHENTICATION', default=False, cast=bool)

########################      CRONJOB     ######################

ENABLE_CHATBOT_CRONS = config('ENABLE_CHATBOT_CRONS', default=False, cast=bool)
ENABLE_WHATSAPP_CRONS = config(
    'ENABLE_WHATSAPP_CRONS', default=False, cast=bool)
ENABLE_VIBER_CRONS = config('ENABLE_VIBER_CRONS', default=False, cast=bool)
ENABLE_LIVECHAT_CRONS = config(
    'ENABLE_LIVECHAT_CRONS', default=False, cast=bool)
ENABLE_CAMPAIGN_CRONS = config(
    'ENABLE_CAMPAIGN_CRONS', default=False, cast=bool)
ENABLE_EASYASSIST_CRONS = config(
    'ENABLE_EASYASSIST_CRONS', default=False, cast=bool)
ENABLE_TMS_CRONS = config('ENABLE_TMS_CRONS', default=False, cast=bool)
ENABLE_PDF_SEARCHER = config('ENABLE_PDF_SEARCHER', default=False, cast=bool)

ENABLE_EXOMIND_PDF_SEARCHER_OPTION = True

CRONJOBS = []
CRONJOBS.append(('4-59/5 * * * *', 'cronjob_scripts.session_timeout.cronjob'))

CRONJOBS.append(('30 20 * * *', 'cronjob_scripts.audit_trail_app_cronjob.cronjob'))

if ENABLE_CHATBOT_CRONS == True:

    #CRONJOBS.append(('* * * * *', 'cronjob_scripts.s_nudge.cronjob'))

    #CRONJOBS.append(('30 4 * * *','cronjob_scripts.emailAverageSession.cronjob'))

    #CRONJOBS.append(('25 4 * * *', 'cronjob_scripts.averageSessionCalculation.cronjob'))

    CRONJOBS.append(('* * * * *', 'cronjob_scripts.custom_dsa_nudging_cronjob.cronjob'))

    CRONJOBS.append(('* * * * *', 'cronjob_scripts.custom_dfd_nudging_cronjob.cronjob'))

    CRONJOBS.append(('3-59/5 * * * *', 'cronjob_scripts.easychat_analytics_export.cronjob'))

    CRONJOBS.append(('30 19 * * *', 'cronjob_scripts.easychat_combined_cronjob.cronjob'))

    CRONJOBS.append(('0 * * * *', 'cronjob_scripts.check_bot_usage_analytics.cronjob'))

    CRONJOBS.append(('15 23 * * *', 'cronjob_scripts.send_easychat_analytics_mail.cronjob'))

    CRONJOBS.append(('15 21 * * *', 'cronjob_scripts.custom_delete_files_tminus1.cronjob'))
    
    #CRONJOBS.append(('15 23 * * *', 'cronjob_scripts.custom_whatsapp_sessiontimeout_message.cronjob'))

    CRONJOBS.append(('0 */2 * * *', 'cronjob_scripts.custom_dsa_report.cronjob'))

    if ENABLE_WHATSAPP_CRONS == True:

        CRONJOBS.append(('1-59/5 * * * *', 'cronjob_scripts.csat_whatsapp.cronjob'))

        CRONJOBS.append(('* * * * *', 'cronjob_scripts.whatsapp_campaign_trigger_cronjob.cronjob'))

    if ENABLE_VIBER_CRONS == True:

        CRONJOBS.append(('2-59/5 * * * *', 'cronjob_scripts.csat_viber.cronjob'))

if ENABLE_LIVECHAT_CRONS == True:

    CRONJOBS.append(('0 19 * * *', 'cronjob_scripts.livechat_combined_cronjob.cronjob'))

    CRONJOBS.append(('0 22 * * *', 'cronjob_scripts.livechat_send_mail_analytics.cronjob'))

if ENABLE_CAMPAIGN_CRONS == True:

    CRONJOBS.append(('5-59/10 * * * *', 'cronjob_scripts.campaign_analytics_update_cronjob.cronjob'))

    CRONJOBS.append(('10 21 * * *', 'cronjob_scripts.send_campaign_daily_mailer.cronjob'))

    CRONJOBS.append(('15 18 * * *', 'cronjob_scripts.campaign_export.cronjob'))

    CRONJOBS.append(('30 22 * * *', 'cronjob_scripts.export_whatsapp_campaign_history_data.cronjob'))

if ENABLE_EASYASSIST_CRONS == True:

    CRONJOBS.append(('0 23 * * *', 'cronjob_scripts.easyassist_combined_cronjob.cronjob'))

    CRONJOBS.append(('0 * * * *', 'cronjob_scripts.easyassist_mask_customer_details_cronjob.cronjob'))

if ENABLE_TMS_CRONS == True:

    CRONJOBS.append(('0 20 * * *', 'cronjob_scripts.tms_analytics_cronjob.cronjob'))

if ENABLE_PDF_SEARCHER == True:

    CRONJOBS.append(('20 */12 * * *', 'cronjob_scripts.pdf_search_export.cronjob'))

# CRONJOBS = [
    # ('1-59/5 * * * *', 'cronjob_scripts.csat_whatsapp.cronjob'),
    # ('2-59/5 * * * *', 'cronjob_scripts.csat_viber.cronjob'),
    # ('3-59/5 * * * *', 'cronjob_scripts.easychat_analytics_export.cronjob'),
    # ('* * * * *', 'cronjob_scripts.whatsapp_campaign_trigger_cronjob.cronjob'),
    # ('5-59/10 * * * *', 'cronjob_scripts.campaign_analytics_update_cronjob.cronjob'),
    # ('19 2 * * *', 'cronjob_scripts.campaign_sync_templates_cronjob.cronjob'),
    # ('10 21 * * *', 'cronjob_scripts.send_campaign_daily_mailer.cronjob'),
    # ('0 19 * * *', 'cronjob_scripts.livechat_combined_cronjob.cronjob'),
    # ('30 19 * * *', 'cronjob_scripts.easychat_combined_cronjob.cronjob'),
    # ('0 * * * *', 'cronjob_scripts.check_bot_usage_analytics.cronjob'),
    # ('4-59/5 * * * *', 'cronjob_scripts.session_timeout.cronjob'),
    # ('0 23 * * *', 'cronjob_scripts.easyassist_combined_cronjob.cronjob'),
    # ('0 20 * * *', 'cronjob_scripts.tms_analytics_cronjob.cronjob'),
    # ('30 20 * * *', 'cronjob_scripts.audit_trail_app_cronjob.cronjob'),
    # ('0 * * * *', 'cronjob_scripts.easyassist_mask_customer_details_cronjob.cronjob'),
    # ('15 18 * * *', 'cronjob_scripts.campaign_export.cronjob'),
    # ('20 */12 * * *', 'cronjob_scripts.pdf_search_export.cronjob'),
    # ('0 22 * * *', 'cronjob_scripts.livechat_send_mail_analytics.cronjob'),
    # ('15 23 * * *', 'cronjob_scripts.send_easychat_analytics_mail.cronjob'),
    # ('30 22 * * *', 'cronjob_scripts.export_whatsapp_campaign_history_data.cronjob'),
# ]
