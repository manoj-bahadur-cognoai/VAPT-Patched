"""
Dynamic CAPTCHA generation for CustomApp.

Replaces the finite static image pool (EasyChatApp/captcha_images + captcha_key
dict) with a fresh Pillow-rendered challenge per request. Challenge values are
stored in Django cache and are single-use.
"""
from __future__ import annotations

import io
import os
import random
import secrets
import string
from typing import Optional, Tuple

from django.conf import settings
from django.core.cache import cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter

CAPTCHA_CACHE_PREFIX = "custom_app_captcha:"
CAPTCHA_ATTEMPT_PREFIX = "custom_app_captcha_attempts:"
CAPTCHA_LOCK_PREFIX = "custom_app_captcha_lock:"
CAPTCHA_TTL_SECONDS = 600  # 10 minutes
CAPTCHA_MAX_INVALID_ATTEMPTS = 5
CAPTCHA_LOCK_TTL_SECONDS = 30 * 60  # 30 minutes
CAPTCHA_LENGTH = 6
CAPTCHA_WIDTH = 200
CAPTCHA_HEIGHT = 50
# Match historical captcha alphabet (lowercase + digits).
CAPTCHA_ALPHABET = string.ascii_lowercase + string.digits
CAPTCHA_MAX_LIMIT_MESSAGE = (
    "max limit for captcha request reached try after 30min"
)

_FONT_CANDIDATES = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/Library/Fonts/Arial.ttf",
)


def _load_font(size: int = 28) -> ImageFont.ImageFont:
    for path in _FONT_CANDIDATES:
        if os.path.isfile(path):
            try:
                return ImageFont.truetype(path, size=size)
            except OSError:
                continue
    return ImageFont.load_default()


def _generate_text() -> str:
    return "".join(secrets.choice(CAPTCHA_ALPHABET) for _ in range(CAPTCHA_LENGTH))


def _generate_captcha_id() -> str:
    # 16 hex chars — same shape as legacy static captcha filenames.
    return secrets.token_hex(8).upper()


def _render_captcha_image(text: str) -> bytes:
    """Render a 200x50 JPEG captcha with light noise/distortion."""
    image = Image.new("RGB", (CAPTCHA_WIDTH, CAPTCHA_HEIGHT), (245, 245, 245))
    draw = ImageDraw.Draw(image)
    font = _load_font(28)

    # Background noise lines
    for _ in range(6):
        x1 = random.randint(0, CAPTCHA_WIDTH)
        y1 = random.randint(0, CAPTCHA_HEIGHT)
        x2 = random.randint(0, CAPTCHA_WIDTH)
        y2 = random.randint(0, CAPTCHA_HEIGHT)
        draw.line(
            ((x1, y1), (x2, y2)),
            fill=(
                random.randint(160, 210),
                random.randint(160, 210),
                random.randint(160, 210),
            ),
            width=1,
        )

    # Draw characters with slight per-glyph jitter
    approx_char_width = CAPTCHA_WIDTH // (CAPTCHA_LENGTH + 1)
    x = approx_char_width // 2
    for char in text:
        y = random.randint(8, 16)
        draw.text(
            (x, y),
            char,
            font=font,
            fill=(
                random.randint(10, 60),
                random.randint(10, 60),
                random.randint(10, 60),
            ),
        )
        x += approx_char_width

    # Speckle noise
    pixels = image.load()
    for _ in range(120):
        px = random.randint(0, CAPTCHA_WIDTH - 1)
        py = random.randint(0, CAPTCHA_HEIGHT - 1)
        pixels[px, py] = (
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255),
        )

    image = image.filter(ImageFilter.SMOOTH)
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=85)
    return buffer.getvalue()


def create_captcha_challenge(owner_subject: str = "") -> Tuple[str, str]:
    """
    Create a fresh captcha challenge.

    owner_subject is the authenticated rate-limit identity that minted the
    challenge; validation must use the same subject for locks.

    Returns:
        (captcha_id, public_image_url)
    """
    captcha_id = _generate_captcha_id()
    text = _generate_text()
    image_bytes = _render_captcha_image(text)

    cache.set(
        CAPTCHA_CACHE_PREFIX + captcha_id,
        {
            "value": text,
            "image": image_bytes,
            "owner": str(owner_subject or ""),
        },
        CAPTCHA_TTL_SECONDS,
    )

    image_url = (
        f"{settings.EASYCHAT_DOMAIN}/custom-app/captcha-challenge/{captcha_id}.jpg"
    )
    return captcha_id, image_url


def get_captcha_image_bytes(captcha_id: str) -> Optional[bytes]:
    payload = cache.get(CAPTCHA_CACHE_PREFIX + str(captcha_id).upper())
    if not payload:
        return None
    return payload.get("image")


def get_captcha_owner(captcha_id: str) -> Optional[str]:
    """Return the authenticated subject bound to this challenge, if any."""
    payload = cache.get(CAPTCHA_CACHE_PREFIX + str(captcha_id).upper())
    if not payload:
        return None
    owner = payload.get("owner")
    return str(owner) if owner else None


def verify_captcha(captcha_id: str, user_value: str, *, consume: bool = True) -> bool:
    """
    Compare user input to the cached challenge value.

    When consume=True (default), the challenge is deleted after a successful
    match so the same image cannot be reused.
    """
    cache_key = CAPTCHA_CACHE_PREFIX + str(captcha_id).upper()
    payload = cache.get(cache_key)
    if not payload:
        return False

    expected = str(payload.get("value", ""))
    provided = str(user_value or "")
    # Constant-time where lengths match; unequal length is an automatic miss.
    matched = (
        len(expected) == len(provided)
        and secrets.compare_digest(expected, provided)
    )

    if matched and consume:
        cache.delete(cache_key)
    return matched


def extract_captcha_id_from_url(captcha_image_url: str) -> str:
    """Extract captcha id from a challenge URL or legacy static image URL."""
    if not captcha_image_url:
        raise ValueError("captcha_image URL is empty")
    filename = captcha_image_url.rstrip("/").split("/")[-1]
    # Challenges are stored under uppercase ids — normalize lookups.
    return filename.split(".")[0].upper()


def _captcha_rate_identities(
    user_id: str = "", captcha_id: str = ""
) -> Tuple[str, ...]:
    """Cache identity keys for attempt/lock tracking (subject + challenge).

    user_id here must be a trusted rate-limit subject from the authenticated
    principal / verified session user — never a raw unverified body field.
    IP is intentionally not used: behind ALB the address is the load balancer.
    """
    identities = []
    if user_id:
        identities.append(f"user:{user_id}")
    if captcha_id:
        identities.append(f"captcha:{str(captcha_id).upper()}")
    return tuple(identities)


def is_captcha_validation_locked(
    *, user_id: str = "", captcha_id: str = ""
) -> bool:
    """
    True when user or challenge is blocked from further validation.

    Closes unlimited Intruder attempts against captcha_value.
    """
    for identity in _captcha_rate_identities(user_id, captcha_id):
        if cache.get(CAPTCHA_LOCK_PREFIX + identity):
            return True
    return False


def clear_captcha_attempts(*, user_id: str = "", captcha_id: str = "") -> None:
    """Clear invalid-attempt counters and locks after a successful validation."""
    for identity in _captcha_rate_identities(user_id, captcha_id):
        cache.delete(CAPTCHA_ATTEMPT_PREFIX + identity)
        cache.delete(CAPTCHA_LOCK_PREFIX + identity)


def record_invalid_captcha_attempt(
    *, user_id: str = "", captcha_id: str = ""
) -> bool:
    """
    Increment invalid captcha attempts for user and challenge.

    After CAPTCHA_MAX_INVALID_ATTEMPTS failures on any identity, locks that
    identity for CAPTCHA_LOCK_TTL_SECONDS. When the challenge itself is locked,
    the cached challenge is deleted so further guesses cannot succeed.
    Returns True if any identity is now locked.
    """
    locked_any = False
    for identity in _captcha_rate_identities(user_id, captcha_id):
        attempt_key = CAPTCHA_ATTEMPT_PREFIX + identity
        lock_key = CAPTCHA_LOCK_PREFIX + identity

        attempts = cache.get(attempt_key)
        if attempts is None:
            attempts = 0
        attempts = int(attempts) + 1
        cache.set(attempt_key, attempts, CAPTCHA_LOCK_TTL_SECONDS)

        if attempts >= CAPTCHA_MAX_INVALID_ATTEMPTS:
            cache.set(lock_key, True, CAPTCHA_LOCK_TTL_SECONDS)
            cache.delete(attempt_key)
            locked_any = True

    if locked_any and captcha_id:
        # Invalidate the challenge so Intruder cannot keep guessing the same image.
        cache.delete(CAPTCHA_CACHE_PREFIX + str(captcha_id).upper())

    return locked_any
