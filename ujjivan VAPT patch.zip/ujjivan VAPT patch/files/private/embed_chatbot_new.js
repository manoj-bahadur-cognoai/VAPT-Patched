var easychat_form_assist_id = ""
var easychat_page_category = ""
var easychat_minimized_chatbot = false
var easychat_do_not_disturb = ""

/** Exact origin of SERVER_URL for postMessage trust checks (never substring / "*"). */
function get_easychat_server_origin() {
    try {
        if (typeof SERVER_URL !== 'string' || !SERVER_URL || SERVER_URL === '*') {
            return null;
        }
        var anchor = document.createElement('a');
        anchor.href = SERVER_URL;
        if (!anchor.protocol || !anchor.host) {
            return null;
        }
        return anchor.protocol + '//' + anchor.host;
    } catch (err) {
        return null;
    }
}

function is_trusted_chatbot_postmessage_origin(origin) {
    if (!origin || typeof origin !== 'string' || origin === '*') {
        return false;
    }
    var server_origin = get_easychat_server_origin();
    return !!server_origin && origin === server_origin;
}

// Include CSS files
function easychat_add_css(filename) {
    var head = document.getElementsByTagName('head')[0];
    var style = document.createElement('link');
    style.href = filename;
    style.type = 'text/css';
    style.rel = 'stylesheet';
    document.head.appendChild(style);
}

// Include script files
function easychat_add_script(filename) {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.src = filename;
    script.type = 'text/javascript';
    document.head.appendChild(script)
}

easychat_add_css(SERVER_URL + "/static/EasyChatApp/css/embed.css");
easychat_add_script(SERVER_URL + "/static/EasyChatApp/js/crypto-js.min.js");


// Import form assist code when form assist is allowed
if (is_form_assist == "true") {
    easychat_add_script(SERVER_URL + "/files/private/form_assist.js")
}

if (is_easyassist_enabled == "true"){
    easychat_add_script(SERVER_URL + "/static/EasyAssistApp/js/easy-assist-v6.js?key="+easyassist_token);
}

// var slideIndex = 1;

function easychat_get_url_vars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
        vars[key] = value;
    });
    return vars;
}

// On windows loads
window.onload = function() {
    if(is_lead_generation == 'true'){
        is_form_assist = 'false'
    }
    //If form asssit is true call form assist function in form_assist.js

    var easychat_iframe = document.createElement('iframe');
    easychat_iframe.style.display = "none";
    easychat_iframe.id = "allincall-chat-box";
    easychat_iframe.frameborder = "0";
    easychat_iframe.zIndex = "2147483647";
    easychat_iframe.backgroundColor = "white";
    document.body.appendChild(easychat_iframe);

    url_parameters = easychat_get_url_vars();

    var xhttp = new XMLHttpRequest();
    var params = 'bot_id=' + BOT_ID;
    xhttp.open("POST", SERVER_URL + "/chat/get-bot-image/", true);
    xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            response = JSON.parse(this.responseText);
            var easychat_popup_image = document.createElement("img");
            easychat_popup_image.id = "allincall-popup";
            easychat_popup_image.style.position = "fixed";
            easychat_popup_image.style.cursor = "pointer";
            easychat_popup_image.style.right = "20px";
            easychat_popup_image.style.bottom = "0";
            easychat_popup_image.style.width = "8em";
            easychat_popup_image.zIndex = "2147483647";
            window.form_assist_autopop_up_timer = response.form_assist_autopop_up_timer;
            window.form_assist_inactivity_timer = response.form_assist_inactivity_timer;

            if (response.status == 200 && response.bot_image_url != "") {
                easychat_popup_image.src = SERVER_URL + response.bot_image_url;
            } else {
                easychat_popup_image.src = SERVER_URL + "/static/EasyChatApp/img/popup-3.svg";
            }

            if (is_form_assist == "true") {
                callFormAssist()
            }

            document.body.appendChild(easychat_popup_image);
            // document.getElementById("allincall-chat-box").src= SERVER_URL+"/chat/index/?id="+BOT_ID+'&name='+BOT_NAME+'&theme='+BOT_THEME+'&form_assist_intent_name='+easychat_form_assist_id+'&easychat_page_category='+easychat_page_category.toString();
            
            document.getElementById("allincall-popup").addEventListener("click", function(e) 
            {
                console.log("allincall-popup click");
                document.getElementById("allincall-chat-box").style.display = "block";
                
                if(is_form_assist == 'true')
                {
                    easychat_do_not_disturb = is_form_assist_active()
                    easychat_form_assist_id = get_form_assist_id()
                    console.log(easychat_form_assist_id)
                    console.log("Do not Disturb: "+ easychat_do_not_disturb)
                    if(easychat_do_not_disturb == true && easychat_form_assist_id == "")
                    {
                        is_trigger_bot_allowed = 0;
                        openChatBot();
                    }
                    else if(easychat_minimized_chatbot != true)
                    {
                        document.getElementById("allincall-chat-box").src = SERVER_URL + "/chat/index/?id=" + BOT_ID + '&name=' + BOT_NAME + '&theme=' + BOT_THEME + '&form_assist_id=' + easychat_form_assist_id + '&do_not_disturb=' + easychat_do_not_disturb  +  '&is_lead_generation='+ is_lead_generation+  '&page_category=' + easychat_page_category.toString();
                    }
                }
                else if(easychat_minimized_chatbot != true)
                {
                    document.getElementById("allincall-chat-box").src = SERVER_URL + "/chat/index/?id=" + BOT_ID + '&name=' + BOT_NAME + '&theme=' + BOT_THEME + '&form_assist_id=' + easychat_form_assist_id + '&do_not_disturb=' + easychat_do_not_disturb  +  '&is_lead_generation='+ is_lead_generation+  '&page_category=' + easychat_page_category.toString();
                }
                this.style.display = "none";
            });
            if(is_lead_generation == 'true'){
                setTimeout(function(e){
                    document.getElementById("allincall-popup").click();
                },3000)
            }
        }
    }
    xhttp.send(params);

    window.addEventListener('message', function(event) {
        // Only accept messages from the chatbot host origin (exact match)
        if (is_trusted_chatbot_postmessage_origin(event.origin)) {
            // The data has been sent from your site 
            // The data sent with postMessage is stored in event.data
            if(event.data.indexOf("connect-with-agent")!=-1 && is_easyassist_enabled=="true"){
                json_data = JSON.parse(event.data);
                connect_with_easyassist_agent_with_details(json_data["full_name"], json_data["mobile_number"]);
                stop_all_activity();
                window.clearTimeout(timer);
                $('#allincall-chat-box', window.document).hide("slow");
                $('#allincall-popup', window.document).show("slow");
                return;
            }

            if(is_form_assist == 'true'){
                if(event.data == "disable-form-assist"){
                    $('#allincall-chat-box', window.document).hide("slow");
                    $('#allincall-popup', window.document).show("slow");
                    easychat_form_assist_id = "";
                    element_id = ""
                    window.clearTimeout(timer);
                    stop_all_activity()
                }
                if(event.data == "enable-form-assist"){
                    window.clearTimeout(timer);
                    enable_form_assist()
                }
            }

            if (event.data == "minimize-chatbot") {
                $('#allincall-chat-box', window.document).hide("slow");
                $('#allincall-popup', window.document).show("slow");
                easychat_minimized_chatbot = true;
                easychat_page_category = "";
                easychat_form_assist_id = "";
                if(is_form_assist == 'true'){
                    element_id = ""
                    window.clearTimeout(timer);
                    timer_is_on = 0
                    check_user_activity_status()
                }
            }

            if (event.data == "close-bot") {
                $('#allincall-chat-box', window.document).hide("slow");
                $('#allincall-popup', window.document).show("slow");
                easychat_page_category = "";
                easychat_form_assist_id = "";
                easychat_minimized_chatbot = false;
                if(is_form_assist == 'true'){
                    element_id = ""
                    window.clearTimeout(timer);
                    timer_is_on = 0
                    check_user_activity_status()
                }
            }

            if (event.data == "share-screen") {
                share_screen();
            }

            if(is_form_assist == 'true'){
                if (event.data == 'stop-form-assist') {
                    clearTimeout(timer);
                    stop_form_assist = true
                    easychat_form_assist_id = "";
                    stop_user_activity_status();
                }
            }
        } else {
            // The data hasn't been sent from your site! 
            // Be careful! Do not use it. 
            return;
        }

    });
}
