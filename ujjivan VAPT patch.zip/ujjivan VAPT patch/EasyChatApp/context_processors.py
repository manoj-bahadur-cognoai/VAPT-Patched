import json

from django.conf import settings
from DeveloperConsoleApp.utils import get_developer_console_settings


def is_console_logs(request):
    config_obj = get_developer_console_settings()
    if config_obj:
        return {'SHOW_CONSOLE_LOGS': config_obj.show_console_logs}
    else:
        return {'SHOW_CONSOLE_LOGS': settings.EASYCHAT_SHOW_CONSOLE_LOGS}
    

def is_quicksight_analytics_enabled(request):
    return {
        'ENABLE_QUICKSIGHT_ANALYTICS': settings.ENABLE_QUICKSIGHT_ANALYTICS
    }

def is_cookies_attributes_enabled(request):
    return {
        'COOKIE_SECURE': settings.COOKIE_SECURE,
        'COOKIE_SAMESITE': settings.COOKIE_SAMESITE,
        'COOKIE_PATH': settings.COOKIE_PATH
    }


def postmessage_allowed_origins(request):
    origins = getattr(settings, 'POSTMESSAGE_ALLOWED_ORIGINS', [])
    return {
        'POSTMESSAGE_ALLOWED_ORIGINS_JSON': json.dumps(list(origins)),
    }


def google_maps_api_key(request):
    return {
        'GOOGLE_MAPS_API_KEY': getattr(settings, 'GOOGLE_MAPS_API_KEY', ''),
    }
