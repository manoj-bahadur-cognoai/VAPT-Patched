from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'get-captcha-image', views.getCaptchaImage),
    url(
        r'captcha-challenge/(?P<captcha_id>[A-Fa-f0-9]+)\.jpg$',
        views.serveCaptchaChallenge,
    ),
    url(r'validate-captcha-image', views.validateCaptcha),
    url(r'account-opening-status/', views.AccountOpeningStatus),
    url(r'dsa-vkyc-data/', views.vkycData),
    url(r'dsa-vkyc-status/', views.vkycStatus),
    url(r'dsa-ekyc-data/', views.ekycData),
]
